CREATE TABLE IF NOT EXISTS commodity_trades (
 id SERIAL PRIMARY KEY, trade_no VARCHAR(40) NOT NULL UNIQUE, commodity_type VARCHAR(16) NOT NULL,
 direction VARCHAR(12) NOT NULL, trade_date DATE NOT NULL, counterparty VARCHAR(180) NOT NULL,
 quantity NUMERIC(20,6) NOT NULL CHECK(quantity > 0), unit VARCHAR(24) NOT NULL,
 unit_price NUMERIC(20,6) NOT NULL CHECK(unit_price > 0), currency VARCHAR(3) NOT NULL CHECK(currency IN ('USD','IQD')),
 extra_cost NUMERIC(20,4) NOT NULL DEFAULT 0 CHECK(extra_cost >= 0), reference VARCHAR(120), notes TEXT,
 created_by INTEGER NOT NULL REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 CONSTRAINT ck_trade_commodity CHECK(commodity_type IN ('fuel','gold','silver')),
 CONSTRAINT ck_trade_direction CHECK(direction IN ('purchase','sale'))
);
CREATE INDEX IF NOT EXISTS ix_trade_type_date ON commodity_trades(commodity_type,trade_date);
CREATE TABLE IF NOT EXISTS external_investments (
 id SERIAL PRIMARY KEY, investment_code VARCHAR(40) NOT NULL UNIQUE, company_name VARCHAR(180) NOT NULL,
 investment_date DATE NOT NULL, invested_amount NUMERIC(20,4) NOT NULL CHECK(invested_amount > 0),
 currency VARCHAR(3) NOT NULL CHECK(currency IN ('USD','IQD')), ownership_percent NUMERIC(7,4),
 status VARCHAR(16) NOT NULL DEFAULT 'active', notes TEXT, created_by INTEGER NOT NULL REFERENCES users(id),
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), CHECK(ownership_percent IS NULL OR ownership_percent BETWEEN 0 AND 100),
 CHECK(status IN ('active','exited','paused'))
);
CREATE TABLE IF NOT EXISTS external_investment_income (
 id SERIAL PRIMARY KEY, investment_id INTEGER NOT NULL REFERENCES external_investments(id) ON DELETE CASCADE,
 income_date DATE NOT NULL, amount NUMERIC(20,4) NOT NULL CHECK(amount > 0), currency VARCHAR(3) NOT NULL CHECK(currency IN ('USD','IQD')),
 period_label VARCHAR(40), notes VARCHAR(500), created_by INTEGER NOT NULL REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS inventory_items (
 id SERIAL PRIMARY KEY, sku VARCHAR(50) NOT NULL UNIQUE, name VARCHAR(180) NOT NULL, category VARCHAR(60) NOT NULL,
 unit VARCHAR(24) NOT NULL, reorder_level NUMERIC(20,6) NOT NULL DEFAULT 0 CHECK(reorder_level >= 0),
 is_active BOOLEAN NOT NULL DEFAULT TRUE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS inventory_movements (
 id SERIAL PRIMARY KEY, item_id INTEGER NOT NULL REFERENCES inventory_items(id), movement_date DATE NOT NULL,
 movement_type VARCHAR(12) NOT NULL CHECK(movement_type IN ('in','out','adjustment')),
 quantity NUMERIC(20,6) NOT NULL CHECK(quantity > 0), unit_cost NUMERIC(20,6), currency VARCHAR(3),
 reference VARCHAR(120), notes VARCHAR(500), created_by INTEGER NOT NULL REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
 CHECK(currency IS NULL OR currency IN ('USD','IQD'))
);
CREATE TABLE IF NOT EXISTS cash_bank_movements (
 id SERIAL PRIMARY KEY, movement_date DATE NOT NULL, account_id INTEGER NOT NULL REFERENCES accounts(id),
 direction VARCHAR(10) NOT NULL CHECK(direction IN ('in','out')), amount NUMERIC(20,4) NOT NULL CHECK(amount > 0),
 currency VARCHAR(3) NOT NULL CHECK(currency IN ('USD','IQD')), category VARCHAR(80) NOT NULL,
 reference VARCHAR(120), notes VARCHAR(500), created_by INTEGER NOT NULL REFERENCES users(id), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
