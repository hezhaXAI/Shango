-- SH BUSINESS OS v2.5 defensive upgrade.
-- Take and verify a database backup before applying. Safe to re-run.
ALTER TABLE accounts ADD COLUMN IF NOT EXISTS parent_id INTEGER NULL;
ALTER TABLE accounts ADD COLUMN IF NOT EXISTS normal_balance VARCHAR(6) NOT NULL DEFAULT 'debit';
ALTER TABLE accounts ADD COLUMN IF NOT EXISTS is_group BOOLEAN NOT NULL DEFAULT FALSE;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conrelid = 'accounts'::regclass AND contype = 'f'
      AND pg_get_constraintdef(oid) LIKE 'FOREIGN KEY (parent_id)%'
  ) THEN
    ALTER TABLE accounts ADD CONSTRAINT fk_accounts_parent_id
      FOREIGN KEY (parent_id) REFERENCES accounts(id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_account_normal_balance') THEN
    ALTER TABLE accounts ADD CONSTRAINT ck_account_normal_balance
      CHECK (normal_balance IN ('debit', 'credit'));
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ck_group_account_no_currency') THEN
    ALTER TABLE accounts ADD CONSTRAINT ck_group_account_no_currency
      CHECK (NOT (is_group = TRUE AND currency IS NOT NULL));
  END IF;
END $$;
