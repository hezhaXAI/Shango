-- SH BUSINESS OS v2.6: general business capital partners and partner loans.
-- Take and verify a PostgreSQL backup before applying.
CREATE TABLE IF NOT EXISTS partners (
    id SERIAL PRIMARY KEY,
    partner_code VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(180) NOT NULL,
    phone VARCHAR(40),
    notes TEXT,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_partners_partner_code ON partners(partner_code);

CREATE TABLE IF NOT EXISTS capital_transactions (
    id SERIAL PRIMARY KEY,
    partner_id INTEGER NOT NULL REFERENCES partners(id),
    transaction_date DATE NOT NULL,
    transaction_type VARCHAR(20) NOT NULL CHECK (transaction_type IN ('contribution','withdrawal')),
    currency VARCHAR(3) NOT NULL CHECK (currency IN ('USD','IQD')),
    amount NUMERIC(20,4) NOT NULL CHECK (amount > 0),
    reference VARCHAR(100),
    notes VARCHAR(500),
    created_by INTEGER NOT NULL REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_capital_tx_partner_date ON capital_transactions(partner_id, transaction_date);

CREATE TABLE IF NOT EXISTS partner_loans (
    id SERIAL PRIMARY KEY,
    loan_no VARCHAR(40) NOT NULL UNIQUE,
    partner_id INTEGER NOT NULL REFERENCES partners(id),
    loan_date DATE NOT NULL,
    currency VARCHAR(3) NOT NULL CHECK (currency IN ('USD','IQD')),
    principal_amount NUMERIC(20,4) NOT NULL CHECK (principal_amount > 0),
    due_date DATE,
    interest_rate NUMERIC(9,6) NOT NULL DEFAULT 0 CHECK (interest_rate >= 0),
    status VARCHAR(16) NOT NULL DEFAULT 'open' CHECK (status IN ('open','settled','cancelled')),
    reference VARCHAR(100),
    notes VARCHAR(500),
    created_by INTEGER NOT NULL REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK (due_date IS NULL OR due_date >= loan_date)
);
CREATE INDEX IF NOT EXISTS ix_partner_loan_partner_date ON partner_loans(partner_id, loan_date);

CREATE TABLE IF NOT EXISTS partner_loan_payments (
    id SERIAL PRIMARY KEY,
    loan_id INTEGER NOT NULL REFERENCES partner_loans(id),
    payment_date DATE NOT NULL,
    amount NUMERIC(20,4) NOT NULL CHECK (amount > 0),
    reference VARCHAR(100),
    notes VARCHAR(500),
    created_by INTEGER NOT NULL REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_partner_loan_payment_date ON partner_loan_payments(loan_id, payment_date);
