-- SH BUSINESS OS v2.8: deal-specific property investment records.
-- Back up PostgreSQL before applying. Apply after migrations 0001-0005.
CREATE TABLE IF NOT EXISTS property_deals (
    id SERIAL PRIMARY KEY,
    deal_code VARCHAR(40) NOT NULL UNIQUE,
    title VARCHAR(180) NOT NULL,
    location VARCHAR(240) NOT NULL,
    area_sqm NUMERIC(18,4) CHECK (area_sqm IS NULL OR area_sqm > 0),
    currency VARCHAR(3) NOT NULL CHECK (currency IN ('USD','IQD')),
    purchase_price NUMERIC(20,4) NOT NULL CHECK (purchase_price > 0),
    purchase_date DATE NOT NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'open' CHECK (status IN ('open','sold','cancelled')),
    title_document_ref VARCHAR(300),
    notes TEXT,
    created_by INTEGER NOT NULL REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS ix_property_deals_deal_code ON property_deals(deal_code);

CREATE TABLE IF NOT EXISTS property_participants (
    id SERIAL PRIMARY KEY,
    deal_id INTEGER NOT NULL REFERENCES property_deals(id) ON DELETE CASCADE,
    participant_name VARCHAR(180) NOT NULL,
    participant_type VARCHAR(24) NOT NULL CHECK (participant_type IN ('owner','outside_investor')),
    partner_id INTEGER REFERENCES partners(id),
    contribution_amount NUMERIC(20,4) NOT NULL DEFAULT 0 CHECK (contribution_amount >= 0),
    currency VARCHAR(3) NOT NULL CHECK (currency IN ('USD','IQD')),
    legal_ownership_percent NUMERIC(7,4) CHECK (legal_ownership_percent IS NULL OR legal_ownership_percent BETWEEN 0 AND 100),
    profit_share_percent NUMERIC(7,4) CHECK (profit_share_percent IS NULL OR profit_share_percent BETWEEN 0 AND 100),
    agreement_ref VARCHAR(300),
    notes VARCHAR(500),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(deal_id, participant_name)
);

CREATE TABLE IF NOT EXISTS property_expenses (
    id SERIAL PRIMARY KEY,
    deal_id INTEGER NOT NULL REFERENCES property_deals(id) ON DELETE CASCADE,
    expense_date DATE NOT NULL,
    category VARCHAR(80) NOT NULL,
    amount NUMERIC(20,4) NOT NULL CHECK (amount > 0),
    currency VARCHAR(3) NOT NULL CHECK (currency IN ('USD','IQD')),
    notes VARCHAR(500),
    created_by INTEGER NOT NULL REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS property_sales (
    id SERIAL PRIMARY KEY,
    deal_id INTEGER NOT NULL UNIQUE REFERENCES property_deals(id) ON DELETE CASCADE,
    sale_date DATE NOT NULL,
    sale_amount NUMERIC(20,4) NOT NULL CHECK (sale_amount > 0),
    currency VARCHAR(3) NOT NULL CHECK (currency IN ('USD','IQD')),
    received_amount NUMERIC(20,4) NOT NULL DEFAULT 0 CHECK (received_amount >= 0 AND received_amount <= sale_amount),
    notes VARCHAR(500),
    created_by INTEGER NOT NULL REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS property_payments (
    id SERIAL PRIMARY KEY,
    deal_id INTEGER NOT NULL REFERENCES property_deals(id) ON DELETE CASCADE,
    participant_id INTEGER REFERENCES property_participants(id),
    payment_type VARCHAR(28) NOT NULL CHECK (payment_type IN ('participant_contribution','purchase_payment','sale_receipt')),
    payment_date DATE NOT NULL,
    amount NUMERIC(20,4) NOT NULL CHECK (amount > 0),
    currency VARCHAR(3) NOT NULL CHECK (currency IN ('USD','IQD')),
    reference VARCHAR(120),
    notes VARCHAR(500),
    created_by INTEGER NOT NULL REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CHECK ((payment_type = 'participant_contribution' AND participant_id IS NOT NULL) OR
           (payment_type <> 'participant_contribution' AND participant_id IS NULL))
);
CREATE INDEX IF NOT EXISTS ix_property_payments_deal_date ON property_payments(deal_id, payment_date);
