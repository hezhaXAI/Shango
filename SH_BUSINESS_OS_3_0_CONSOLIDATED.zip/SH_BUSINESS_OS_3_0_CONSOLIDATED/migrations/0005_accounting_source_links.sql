CREATE TABLE IF NOT EXISTS journal_source_links (
    id SERIAL PRIMARY KEY,
    source_type VARCHAR(40) NOT NULL,
    source_id INTEGER NOT NULL,
    journal_entry_id INTEGER NOT NULL UNIQUE REFERENCES journal_entries(id),
    created_by INTEGER NOT NULL REFERENCES users(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_journal_source_event UNIQUE (source_type, source_id),
    CONSTRAINT ck_journal_source_type CHECK (source_type IN ('capital_transaction','partner_loan','partner_loan_payment'))
);
CREATE INDEX IF NOT EXISTS ix_journal_source_lookup ON journal_source_links(source_type, source_id);
