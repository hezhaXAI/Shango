from decimal import Decimal
import pytest
from app.accounting_rules import validate_balanced_lines, AccountingValidationError

def test_opening_balances_must_balance_each_currency_independently():
    validate_balanced_lines([
        {"side": "debit", "currency": "USD", "amount": Decimal("2500")},
        {"side": "credit", "currency": "USD", "amount": Decimal("2500")},
        {"side": "debit", "currency": "IQD", "amount": Decimal("3750000")},
        {"side": "credit", "currency": "IQD", "amount": Decimal("3750000")},
    ])

def test_usd_surplus_cannot_offset_iqd_shortfall():
    with pytest.raises(AccountingValidationError):
        validate_balanced_lines([
            {"side": "debit", "currency": "USD", "amount": Decimal("100")},
            {"side": "credit", "currency": "USD", "amount": Decimal("90")},
            {"side": "debit", "currency": "IQD", "amount": Decimal("90")},
            {"side": "credit", "currency": "IQD", "amount": Decimal("100")},
        ])
