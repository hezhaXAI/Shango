from decimal import Decimal

def net_capital(transactions, currency):
    return sum(
        (Decimal(amount) if kind == "contribution" else -Decimal(amount)
         for kind, curr, amount in transactions if curr == currency),
        Decimal("0")
    )

def test_capital_balance_is_separate_by_currency():
    tx = [
        ("contribution", "USD", "1200"),
        ("withdrawal", "USD", "200"),
        ("contribution", "IQD", "500000"),
    ]
    assert net_capital(tx, "USD") == Decimal("1000")
    assert net_capital(tx, "IQD") == Decimal("500000")

def test_contribution_amount_does_not_imply_profit_share():
    # The ledger deliberately stores cash movements only; no ownership/profit ratio is derived.
    assert "profit_share" not in {"contribution", "withdrawal"}
