from decimal import Decimal
import pytest
from app.accounting_rules import validate_balanced_lines, AccountingValidationError

def test_balanced_usd():
    validate_balanced_lines([
        {"side": "debit", "currency": "USD", "amount": Decimal("100")},
        {"side": "credit", "currency": "USD", "amount": Decimal("100")},
    ])

def test_balances_each_currency_separately():
    validate_balanced_lines([
        {"side": "debit", "currency": "USD", "amount": Decimal("100")},
        {"side": "credit", "currency": "USD", "amount": Decimal("100")},
        {"side": "debit", "currency": "IQD", "amount": Decimal("150000")},
        {"side": "credit", "currency": "IQD", "amount": Decimal("150000")},
    ])

def test_rejects_unbalanced_currency():
    with pytest.raises(AccountingValidationError):
        validate_balanced_lines([
            {"side": "debit", "currency": "USD", "amount": Decimal("100")},
            {"side": "credit", "currency": "USD", "amount": Decimal("99")},
        ])

def test_rejects_mixing_as_offset():
    with pytest.raises(AccountingValidationError):
        validate_balanced_lines([
            {"side": "debit", "currency": "USD", "amount": Decimal("100")},
            {"side": "credit", "currency": "IQD", "amount": Decimal("100")},
        ])
