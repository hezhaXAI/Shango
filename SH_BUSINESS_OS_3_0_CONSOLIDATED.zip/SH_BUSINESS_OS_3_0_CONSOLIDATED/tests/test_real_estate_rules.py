from decimal import Decimal


def calculate_net_result(purchase, expenses, sale):
    if sale is None:
        return None
    return Decimal(sale) - Decimal(purchase) - sum((Decimal(x) for x in expenses), Decimal("0"))


def explicit_profit_allocation(net_result, percent):
    if percent is None:
        return None
    return Decimal(net_result) * Decimal(percent) / Decimal("100")


def test_legal_ownership_and_profit_share_are_independent_of_contribution():
    contribution = Decimal("15000")
    legal_ownership = Decimal("40")
    profit_share = Decimal("60")
    assert contribution == Decimal("15000")
    assert legal_ownership != profit_share


def test_deal_profit_is_purchase_plus_expenses_deducted_from_sale():
    assert calculate_net_result("20000", ["1000", "500"], "26000") == Decimal("4500")


def test_no_sale_means_profit_is_not_yet_realized():
    assert calculate_net_result("20000", ["500"], None) is None


def test_profit_allocation_uses_only_explicit_agreement():
    assert explicit_profit_allocation("4500", "60") == Decimal("2700")
    assert explicit_profit_allocation("4500", None) is None


def test_currency_is_not_converted_or_mixed():
    # Aggregation is intentionally scoped to the deal's selected currency.
    expenses = [("USD", "100"), ("IQD", "50000")]
    usd_total = sum((Decimal(a) for c, a in expenses if c == "USD"), Decimal("0"))
    assert usd_total == Decimal("100")
