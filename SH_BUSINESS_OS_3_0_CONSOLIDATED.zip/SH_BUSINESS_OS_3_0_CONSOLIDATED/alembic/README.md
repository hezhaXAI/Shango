Production database changes must use Alembic migrations. The current development startup uses SQLAlchemy create_all for convenience only. Before production:
1. Add Alembic configuration and initial revision from the reviewed model metadata.
2. Run migrations against an empty staging database.
3. Test upgrade and rollback/forward-recovery.
4. Disable schema auto-creation in production startup.
