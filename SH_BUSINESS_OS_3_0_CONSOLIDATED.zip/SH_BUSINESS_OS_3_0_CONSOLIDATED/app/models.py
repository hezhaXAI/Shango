from datetime import datetime, timezone, date
from decimal import Decimal
from sqlalchemy import (
    String, Integer, Boolean, DateTime, ForeignKey, Numeric, CheckConstraint,
    UniqueConstraint, Date, Text, Index
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database import Base

def utcnow():
    return datetime.now(timezone.utc)

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(512))
    role: Mapped[str] = mapped_column(String(32), default="owner")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

class AccountingPeriod(Base):
    __tablename__ = "accounting_periods"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(80), unique=True)
    starts_on: Mapped[date] = mapped_column(Date)
    ends_on: Mapped[date] = mapped_column(Date)
    status: Mapped[str] = mapped_column(String(16), default="open")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    __table_args__ = (
        CheckConstraint("status IN ('open','closed')", name="ck_period_status"),
        CheckConstraint("ends_on >= starts_on", name="ck_period_dates"),
    )

class Account(Base):
    __tablename__ = "accounts"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(30), unique=True, index=True)
    name_ku: Mapped[str] = mapped_column(String(160))
    account_type: Mapped[str] = mapped_column(String(30))
    currency: Mapped[str | None] = mapped_column(String(3), nullable=True)
    parent_id: Mapped[int | None] = mapped_column(ForeignKey("accounts.id"), nullable=True)
    normal_balance: Mapped[str] = mapped_column(String(6), default="debit")
    is_group: Mapped[bool] = mapped_column(Boolean, default=False)
    parent: Mapped["Account | None"] = relationship(remote_side="Account.id", back_populates="children")
    children: Mapped[list["Account"]] = relationship(back_populates="parent")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    __table_args__ = (
        CheckConstraint("account_type IN ('asset','liability','equity','revenue','expense')", name="ck_account_type"),
        CheckConstraint("currency IS NULL OR currency IN ('USD','IQD')", name="ck_account_currency"),
        CheckConstraint("normal_balance IN ('debit','credit')", name="ck_account_normal_balance"),
        CheckConstraint("NOT (is_group = TRUE AND currency IS NOT NULL)", name="ck_group_account_no_currency"),
    )

class JournalEntry(Base):
    __tablename__ = "journal_entries"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    entry_no: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    entry_date: Mapped[date] = mapped_column(Date)
    description_ku: Mapped[str] = mapped_column(String(500))
    source_module: Mapped[str] = mapped_column(String(40), default="manual")
    status: Mapped[str] = mapped_column(String(20), default="draft")
    period_id: Mapped[int] = mapped_column(ForeignKey("accounting_periods.id"))
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    posted_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    posted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    reversal_of_id: Mapped[int | None] = mapped_column(ForeignKey("journal_entries.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    lines: Mapped[list["JournalLine"]] = relationship(back_populates="entry", cascade="all, delete-orphan")
    __table_args__ = (
        CheckConstraint("status IN ('draft','posted','reversed')", name="ck_journal_status"),
        UniqueConstraint("reversal_of_id", name="uq_journal_reversal_of"),
        Index("ix_journal_date_status", "entry_date", "status"),
    )

class JournalLine(Base):
    __tablename__ = "journal_lines"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    entry_id: Mapped[int] = mapped_column(ForeignKey("journal_entries.id", ondelete="CASCADE"))
    account_id: Mapped[int] = mapped_column(ForeignKey("accounts.id"))
    side: Mapped[str] = mapped_column(String(6))
    currency: Mapped[str] = mapped_column(String(3))
    amount: Mapped[Decimal] = mapped_column(Numeric(20, 4))
    memo_ku: Mapped[str | None] = mapped_column(String(300), nullable=True)
    entry: Mapped[JournalEntry] = relationship(back_populates="lines")
    __table_args__ = (
        CheckConstraint("side IN ('debit', 'credit')", name="ck_journal_line_side"),
        CheckConstraint("amount > 0", name="ck_journal_line_amount_positive"),
        CheckConstraint("currency IN ('USD', 'IQD')", name="ck_journal_line_currency"),
    )

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actor_user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    action: Mapped[str] = mapped_column(String(60))
    entity_type: Mapped[str] = mapped_column(String(60))
    entity_id: Mapped[str] = mapped_column(String(80))
    details: Mapped[str] = mapped_column(Text, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

class Currency(Base):
    __tablename__ = "currencies"
    code: Mapped[str] = mapped_column(String(3), primary_key=True)
    name_ku: Mapped[str] = mapped_column(String(80))

class ExchangeRate(Base):
    __tablename__ = "exchange_rates"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    base_currency: Mapped[str] = mapped_column(ForeignKey("currencies.code"))
    quote_currency: Mapped[str] = mapped_column(ForeignKey("currencies.code"))
    rate: Mapped[Decimal] = mapped_column(Numeric(20, 8))
    effective_date: Mapped[date] = mapped_column(Date)
    source: Mapped[str | None] = mapped_column(String(120), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    __table_args__ = (
        CheckConstraint("rate > 0", name="ck_exchange_rate_positive"),
        CheckConstraint("base_currency <> quote_currency", name="ck_exchange_rate_distinct"),
        UniqueConstraint("base_currency", "quote_currency", "effective_date", name="uq_exchange_rate_day"),
    )


class Partner(Base):
    """General business capital partner; not a customer/vendor or deal-only co-investor."""
    __tablename__ = "partners"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    partner_code: Mapped[str] = mapped_column(String(30), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(180))
    phone: Mapped[str | None] = mapped_column(String(40), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    contributions: Mapped[list["CapitalTransaction"]] = relationship(back_populates="partner")
    loans: Mapped[list["PartnerLoan"]] = relationship(back_populates="partner")


class CapitalTransaction(Base):
    """General business equity movements only; loans live in PartnerLoan."""
    __tablename__ = "capital_transactions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    partner_id: Mapped[int] = mapped_column(ForeignKey("partners.id"))
    transaction_date: Mapped[date] = mapped_column(Date)
    transaction_type: Mapped[str] = mapped_column(String(20))
    currency: Mapped[str] = mapped_column(String(3))
    amount: Mapped[Decimal] = mapped_column(Numeric(20, 4))
    reference: Mapped[str | None] = mapped_column(String(100), nullable=True)
    notes: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    partner: Mapped["Partner"] = relationship(back_populates="contributions")
    __table_args__ = (
        CheckConstraint("transaction_type IN ('contribution','withdrawal')", name="ck_capital_tx_type"),
        CheckConstraint("currency IN ('USD','IQD')", name="ck_capital_tx_currency"),
        CheckConstraint("amount > 0", name="ck_capital_tx_amount"),
        Index("ix_capital_tx_partner_date", "partner_id", "transaction_date"),
    )


class PartnerLoan(Base):
    """Borrowed money owed to a partner; never treated as equity."""
    __tablename__ = "partner_loans"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    loan_no: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    partner_id: Mapped[int] = mapped_column(ForeignKey("partners.id"))
    loan_date: Mapped[date] = mapped_column(Date)
    currency: Mapped[str] = mapped_column(String(3))
    principal_amount: Mapped[Decimal] = mapped_column(Numeric(20, 4))
    due_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    interest_rate: Mapped[Decimal] = mapped_column(Numeric(9, 6), default=0)
    status: Mapped[str] = mapped_column(String(16), default="open")
    reference: Mapped[str | None] = mapped_column(String(100), nullable=True)
    notes: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    partner: Mapped["Partner"] = relationship(back_populates="loans")
    payments: Mapped[list["PartnerLoanPayment"]] = relationship(back_populates="loan")
    __table_args__ = (
        CheckConstraint("currency IN ('USD','IQD')", name="ck_partner_loan_currency"),
        CheckConstraint("principal_amount > 0", name="ck_partner_loan_principal"),
        CheckConstraint("interest_rate >= 0", name="ck_partner_loan_interest"),
        CheckConstraint("status IN ('open','settled','cancelled')", name="ck_partner_loan_status"),
        Index("ix_partner_loan_partner_date", "partner_id", "loan_date"),
    )


class PartnerLoanPayment(Base):
    __tablename__ = "partner_loan_payments"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    loan_id: Mapped[int] = mapped_column(ForeignKey("partner_loans.id"))
    payment_date: Mapped[date] = mapped_column(Date)
    amount: Mapped[Decimal] = mapped_column(Numeric(20, 4))
    reference: Mapped[str | None] = mapped_column(String(100), nullable=True)
    notes: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    loan: Mapped["PartnerLoan"] = relationship(back_populates="payments")
    __table_args__ = (
        CheckConstraint("amount > 0", name="ck_partner_loan_payment_amount"),
        Index("ix_partner_loan_payment_date", "loan_id", "payment_date"),
    )


class JournalSourceLink(Base):
    """One-to-one link from a source financial event to its accounting draft."""
    __tablename__ = "journal_source_links"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source_type: Mapped[str] = mapped_column(String(40))
    source_id: Mapped[int] = mapped_column(Integer)
    journal_entry_id: Mapped[int] = mapped_column(ForeignKey("journal_entries.id"), unique=True)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    __table_args__ = (UniqueConstraint("source_type", "source_id", name="uq_journal_source_event"),)


class PropertyDeal(Base):
    """A single property deal; ownership, funding and profit rights are independent."""
    __tablename__ = "property_deals"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    deal_code: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    title: Mapped[str] = mapped_column(String(180))
    location: Mapped[str] = mapped_column(String(240))
    area_sqm: Mapped[Decimal | None] = mapped_column(Numeric(18, 4), nullable=True)
    currency: Mapped[str] = mapped_column(String(3))
    purchase_price: Mapped[Decimal] = mapped_column(Numeric(20, 4))
    purchase_date: Mapped[date] = mapped_column(Date)
    status: Mapped[str] = mapped_column(String(16), default="open")
    title_document_ref: Mapped[str | None] = mapped_column(String(300), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    participants: Mapped[list["PropertyParticipant"]] = relationship(back_populates="deal", cascade="all, delete-orphan")
    expenses: Mapped[list["PropertyExpense"]] = relationship(back_populates="deal", cascade="all, delete-orphan")
    sales: Mapped[list["PropertySale"]] = relationship(back_populates="deal", cascade="all, delete-orphan")
    __table_args__ = (
        CheckConstraint("currency IN ('USD','IQD')", name="ck_property_deal_currency"),
        CheckConstraint("purchase_price > 0", name="ck_property_purchase_price"),
        CheckConstraint("area_sqm IS NULL OR area_sqm > 0", name="ck_property_area"),
        CheckConstraint("status IN ('open','sold','cancelled')", name="ck_property_status"),
    )


class PropertyParticipant(Base):
    """Deal-only participant. Percentages are explicit and never inferred from funding."""
    __tablename__ = "property_participants"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    deal_id: Mapped[int] = mapped_column(ForeignKey("property_deals.id", ondelete="CASCADE"))
    participant_name: Mapped[str] = mapped_column(String(180))
    participant_type: Mapped[str] = mapped_column(String(24))
    partner_id: Mapped[int | None] = mapped_column(ForeignKey("partners.id"), nullable=True)
    contribution_amount: Mapped[Decimal] = mapped_column(Numeric(20, 4), default=0)
    currency: Mapped[str] = mapped_column(String(3))
    legal_ownership_percent: Mapped[Decimal | None] = mapped_column(Numeric(7, 4), nullable=True)
    profit_share_percent: Mapped[Decimal | None] = mapped_column(Numeric(7, 4), nullable=True)
    agreement_ref: Mapped[str | None] = mapped_column(String(300), nullable=True)
    notes: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    deal: Mapped[PropertyDeal] = relationship(back_populates="participants")
    __table_args__ = (
        CheckConstraint("participant_type IN ('owner','outside_investor')", name="ck_property_participant_type"),
        CheckConstraint("currency IN ('USD','IQD')", name="ck_property_participant_currency"),
        CheckConstraint("contribution_amount >= 0", name="ck_property_contribution_nonnegative"),
        CheckConstraint("legal_ownership_percent IS NULL OR (legal_ownership_percent >= 0 AND legal_ownership_percent <= 100)", name="ck_property_legal_share_range"),
        CheckConstraint("profit_share_percent IS NULL OR (profit_share_percent >= 0 AND profit_share_percent <= 100)", name="ck_property_profit_share_range"),
        UniqueConstraint("deal_id", "participant_name", name="uq_property_participant_name_per_deal"),
    )


class PropertyExpense(Base):
    __tablename__ = "property_expenses"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    deal_id: Mapped[int] = mapped_column(ForeignKey("property_deals.id", ondelete="CASCADE"))
    expense_date: Mapped[date] = mapped_column(Date)
    category: Mapped[str] = mapped_column(String(80))
    amount: Mapped[Decimal] = mapped_column(Numeric(20, 4))
    currency: Mapped[str] = mapped_column(String(3))
    notes: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    deal: Mapped[PropertyDeal] = relationship(back_populates="expenses")
    __table_args__ = (
        CheckConstraint("amount > 0", name="ck_property_expense_amount"),
        CheckConstraint("currency IN ('USD','IQD')", name="ck_property_expense_currency"),
    )


class PropertySale(Base):
    __tablename__ = "property_sales"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    deal_id: Mapped[int] = mapped_column(ForeignKey("property_deals.id", ondelete="CASCADE"))
    sale_date: Mapped[date] = mapped_column(Date)
    sale_amount: Mapped[Decimal] = mapped_column(Numeric(20, 4))
    currency: Mapped[str] = mapped_column(String(3))
    received_amount: Mapped[Decimal] = mapped_column(Numeric(20, 4), default=0)
    notes: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    deal: Mapped[PropertyDeal] = relationship(back_populates="sales")
    __table_args__ = (
        CheckConstraint("sale_amount > 0", name="ck_property_sale_amount"),
        CheckConstraint("received_amount >= 0 AND received_amount <= sale_amount", name="ck_property_sale_received"),
        CheckConstraint("currency IN ('USD','IQD')", name="ck_property_sale_currency"),
        UniqueConstraint("deal_id", name="uq_property_sale_per_deal"),
    )


class PropertyPayment(Base):
    """Installment ledger for participant funding, purchase settlement and sale receipts."""
    __tablename__ = "property_payments"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    deal_id: Mapped[int] = mapped_column(ForeignKey("property_deals.id", ondelete="CASCADE"))
    participant_id: Mapped[int | None] = mapped_column(ForeignKey("property_participants.id"), nullable=True)
    payment_type: Mapped[str] = mapped_column(String(28))
    payment_date: Mapped[date] = mapped_column(Date)
    amount: Mapped[Decimal] = mapped_column(Numeric(20, 4))
    currency: Mapped[str] = mapped_column(String(3))
    reference: Mapped[str | None] = mapped_column(String(120), nullable=True)
    notes: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    __table_args__ = (
        CheckConstraint("payment_type IN ('participant_contribution','purchase_payment','sale_receipt')", name="ck_property_payment_type"),
        CheckConstraint("amount > 0", name="ck_property_payment_amount"),
        CheckConstraint("currency IN ('USD','IQD')", name="ck_property_payment_currency"),
        CheckConstraint("(payment_type = 'participant_contribution' AND participant_id IS NOT NULL) OR (payment_type <> 'participant_contribution' AND participant_id IS NULL)", name="ck_property_payment_participant"),
    )


class CommodityTrade(Base):
    """Fuel, gold and silver purchases/sales. Quantity is stored in the selected unit."""
    __tablename__ = "commodity_trades"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    trade_no: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    commodity_type: Mapped[str] = mapped_column(String(16))  # fuel, gold, silver
    direction: Mapped[str] = mapped_column(String(12))  # purchase, sale
    trade_date: Mapped[date] = mapped_column(Date)
    counterparty: Mapped[str] = mapped_column(String(180))
    quantity: Mapped[Decimal] = mapped_column(Numeric(20, 6))
    unit: Mapped[str] = mapped_column(String(24))
    unit_price: Mapped[Decimal] = mapped_column(Numeric(20, 6))
    currency: Mapped[str] = mapped_column(String(3))
    extra_cost: Mapped[Decimal] = mapped_column(Numeric(20, 4), default=0)
    reference: Mapped[str | None] = mapped_column(String(120), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    __table_args__ = (
        CheckConstraint("commodity_type IN ('fuel','gold','silver')", name="ck_trade_commodity"),
        CheckConstraint("direction IN ('purchase','sale')", name="ck_trade_direction"),
        CheckConstraint("currency IN ('USD','IQD')", name="ck_trade_currency"),
        CheckConstraint("quantity > 0 AND unit_price > 0 AND extra_cost >= 0", name="ck_trade_amounts"),
        Index("ix_trade_type_date", "commodity_type", "trade_date"),
    )

class ExternalInvestment(Base):
    __tablename__ = "external_investments"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    investment_code: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    company_name: Mapped[str] = mapped_column(String(180))
    investment_date: Mapped[date] = mapped_column(Date)
    invested_amount: Mapped[Decimal] = mapped_column(Numeric(20, 4))
    currency: Mapped[str] = mapped_column(String(3))
    ownership_percent: Mapped[Decimal | None] = mapped_column(Numeric(7,4), nullable=True)
    status: Mapped[str] = mapped_column(String(16), default="active")
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    incomes: Mapped[list["ExternalInvestmentIncome"]] = relationship(back_populates="investment", cascade="all, delete-orphan")
    __table_args__ = (CheckConstraint("currency IN ('USD','IQD')", name="ck_ext_inv_currency"), CheckConstraint("invested_amount > 0", name="ck_ext_inv_amount"), CheckConstraint("ownership_percent IS NULL OR (ownership_percent >= 0 AND ownership_percent <= 100)", name="ck_ext_inv_share"), CheckConstraint("status IN ('active','exited','paused')", name="ck_ext_inv_status"))

class ExternalInvestmentIncome(Base):
    __tablename__ = "external_investment_income"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    investment_id: Mapped[int] = mapped_column(ForeignKey("external_investments.id", ondelete="CASCADE"))
    income_date: Mapped[date] = mapped_column(Date)
    amount: Mapped[Decimal] = mapped_column(Numeric(20,4))
    currency: Mapped[str] = mapped_column(String(3))
    period_label: Mapped[str | None] = mapped_column(String(40), nullable=True)
    notes: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    investment: Mapped[ExternalInvestment] = relationship(back_populates="incomes")
    __table_args__ = (CheckConstraint("currency IN ('USD','IQD')", name="ck_ext_income_currency"), CheckConstraint("amount > 0", name="ck_ext_income_amount"))

class InventoryItem(Base):
    __tablename__ = "inventory_items"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    sku: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(180))
    category: Mapped[str] = mapped_column(String(60))
    unit: Mapped[str] = mapped_column(String(24))
    reorder_level: Mapped[Decimal] = mapped_column(Numeric(20,6), default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    __table_args__ = (CheckConstraint("reorder_level >= 0", name="ck_inventory_reorder"),)

class InventoryMovement(Base):
    __tablename__ = "inventory_movements"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    item_id: Mapped[int] = mapped_column(ForeignKey("inventory_items.id"))
    movement_date: Mapped[date] = mapped_column(Date)
    movement_type: Mapped[str] = mapped_column(String(12))
    quantity: Mapped[Decimal] = mapped_column(Numeric(20,6))
    unit_cost: Mapped[Decimal | None] = mapped_column(Numeric(20,6), nullable=True)
    currency: Mapped[str | None] = mapped_column(String(3), nullable=True)
    reference: Mapped[str | None] = mapped_column(String(120), nullable=True)
    notes: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    __table_args__ = (CheckConstraint("movement_type IN ('in','out','adjustment')", name="ck_inventory_movement_type"), CheckConstraint("quantity > 0", name="ck_inventory_quantity"), CheckConstraint("currency IS NULL OR currency IN ('USD','IQD')", name="ck_inventory_currency"))

class CashBankMovement(Base):
    __tablename__ = "cash_bank_movements"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    movement_date: Mapped[date] = mapped_column(Date)
    account_id: Mapped[int] = mapped_column(ForeignKey("accounts.id"))
    direction: Mapped[str] = mapped_column(String(10))
    amount: Mapped[Decimal] = mapped_column(Numeric(20,4))
    currency: Mapped[str] = mapped_column(String(3))
    category: Mapped[str] = mapped_column(String(80))
    reference: Mapped[str | None] = mapped_column(String(120), nullable=True)
    notes: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    __table_args__ = (CheckConstraint("direction IN ('in','out')", name="ck_cash_direction"), CheckConstraint("amount > 0", name="ck_cash_amount"), CheckConstraint("currency IN ('USD','IQD')", name="ck_cash_currency"))
