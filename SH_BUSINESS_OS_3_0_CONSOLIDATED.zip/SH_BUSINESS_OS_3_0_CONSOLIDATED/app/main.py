from datetime import datetime, timezone, date
from decimal import Decimal
from collections import defaultdict
import json
import secrets
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from sqlalchemy import select
from app.config import settings
from app.database import Base, engine, get_db
from app.models import (User, Account, JournalEntry, JournalLine, AccountingPeriod, AuditLog, Currency,
                        Partner, CapitalTransaction, PartnerLoan, PartnerLoanPayment, JournalSourceLink,
                        PropertyDeal, PropertyParticipant, PropertyExpense, PropertySale, PropertyPayment, CommodityTrade, ExternalInvestment, ExternalInvestmentIncome, InventoryItem, InventoryMovement, CashBankMovement)
from app.schemas import (LoginIn, TokenOut, UserOut, AccountIn, AccountOut, JournalIn, JournalOut,
                         PeriodIn, PeriodOut, OpeningBalanceIn, PartnerIn, PartnerOut,
                         CapitalTransactionIn, CapitalTransactionOut, PartnerLoanIn, PartnerLoanOut,
                         PartnerLoanPaymentIn, SourceJournalDraftIn, PropertyDealIn, PropertyDealOut,
                         PropertyParticipantIn, PropertyExpenseIn, PropertySaleIn, PropertyPaymentIn, CommodityTradeIn, ExternalInvestmentIn, ExternalIncomeIn, InventoryItemIn, InventoryMovementIn, CashBankMovementIn)
from app.security import hash_password, verify_password, create_access_token, decode_access_token
from app.accounting_rules import validate_balanced_lines, AccountingValidationError

app = FastAPI(title=settings.app_name, version="3.0.0")
origins = [x.strip() for x in settings.cors_origins.split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True,
                   allow_methods=["GET", "POST"], allow_headers=["Authorization", "Content-Type"])
bearer = HTTPBearer(auto_error=False)

def audit(db: Session, user_id: int, action: str, entity_type: str, entity_id: str, details: dict):
    db.add(AuditLog(actor_user_id=user_id, action=action, entity_type=entity_type,
                    entity_id=entity_id, details=json.dumps(details, ensure_ascii=False, default=str)))


STANDARD_CHART = [
    # code, Kurdish name, type, normal balance, is_group, parent code, currency
    ("1000", "داراییەکان", "asset", "debit", True, None, None),
    ("1100", "کاش و بانک", "asset", "debit", True, "1000", None),
    ("1110", "کاش - دۆلار", "asset", "debit", False, "1100", "USD"),
    ("1120", "کاش - دینار", "asset", "debit", False, "1100", "IQD"),
    ("1130", "بانک - دۆلار", "asset", "debit", False, "1100", "USD"),
    ("1140", "بانک - دینار", "asset", "debit", False, "1100", "IQD"),
    ("1200", "قەرزی وەرگرتنەوە", "asset", "debit", True, "1000", None),
    ("1210", "قەرزی کڕیاران", "asset", "debit", False, "1200", None),
    ("1300", "کۆگا و کاڵا", "asset", "debit", True, "1000", None),
    ("1310", "کۆگای نەوت و سووتەمەنی", "asset", "debit", False, "1300", None),
    ("1320", "کۆگای زێڕ و زیو", "asset", "debit", False, "1300", None),
    ("1400", "زەوی و خانووبەرە بۆ فرۆشتن", "asset", "debit", False, "1000", None),
    ("1500", "وەبەرهێنان لە کۆمپانیاکان", "asset", "debit", False, "1000", None),
    ("2000", "قەرز و پابەندییەکان", "liability", "credit", True, None, None),
    ("2100", "قەرزی کڕیاران/فرۆشیاران", "liability", "credit", True, "2000", None),
    ("2110", "قەرزی فرۆشیاران", "liability", "credit", False, "2100", None),
    ("2200", "قەرزی وەرگیراو", "liability", "credit", False, "2000", None),
    ("2300", "پابەندییەکانی هاوبەشانی مامەڵە", "liability", "credit", False, "2000", None),
    ("3000", "سەرمایە", "equity", "credit", True, None, None),
    ("3100", "سەرمایەی خاوەن کاروبار", "equity", "credit", False, "3000", None),
    ("3200", "سەرمایەی هاوبەشانی گشتی", "equity", "credit", False, "3000", None),
    ("3300", "قازانجی کۆکراوە", "equity", "credit", False, "3000", None),
    ("3400", "هەژماری باڵانسی دەستپێک", "equity", "credit", False, "3000", None),
    ("4000", "داهات", "revenue", "credit", True, None, None),
    ("4100", "داهاتی فرۆشتنی زەوی", "revenue", "credit", False, "4000", None),
    ("4200", "داهاتی بازرگانی نەوت", "revenue", "credit", False, "4000", None),
    ("4300", "داهاتی زێڕ و زیو", "revenue", "credit", False, "4000", None),
    ("4400", "داهاتی وەبەرهێنان", "revenue", "credit", False, "4000", None),
    ("5000", "خەرجی", "expense", "debit", True, None, None),
    ("5100", "خەرجی مامەڵەی زەوی", "expense", "debit", False, "5000", None),
    ("5200", "خەرجی گواستنەوە و بارکردن", "expense", "debit", False, "5000", None),
    ("5300", "خەرجی گشتی و کارگێڕی", "expense", "debit", False, "5000", None),
    ("5400", "خەرجی بانکی و ئاڵوگۆڕی دراو", "expense", "debit", False, "5000", None),
]

def seed_standard_chart(db: Session):
    existing = {a.code: a for a in db.scalars(select(Account)).all()}
    for code, name, typ, normal, is_group, parent_code, currency in STANDARD_CHART:
        if code not in existing:
            parent_id = existing[parent_code].id if parent_code and parent_code in existing else None
            account = Account(
                code=code, name_ku=name, account_type=typ, currency=currency,
                parent_id=parent_id, normal_balance=normal, is_group=is_group, is_active=True
            )
            db.add(account)
            db.flush()
            existing[code] = account
    db.commit()

@app.on_event("startup")
def startup():
    # Development convenience only. Production must use reviewed Alembic migrations.
    Base.metadata.create_all(bind=engine)
    with Session(engine) as db:
        owner = db.scalar(select(User).where(User.email == settings.owner_email.lower()))
        if owner is None:
            db.add(User(email=settings.owner_email.lower(), password_hash=hash_password(settings.owner_password), role="owner"))
        for code, name in [("USD", "دۆلاری ئەمریکی"), ("IQD", "دیناری عێراقی")]:
            if db.get(Currency, code) is None:
                db.add(Currency(code=code, name_ku=name))
        db.commit()
        seed_standard_chart(db)

def current_user(credentials: HTTPAuthorizationCredentials | None = Depends(bearer),
                  db: Session = Depends(get_db)) -> User:
    if credentials is None:
        raise HTTPException(status_code=401, detail="پێویستە بچیتە ژوورەوە")
    email = decode_access_token(credentials.credentials)
    user = db.scalar(select(User).where(User.email == email, User.is_active == True))
    if user is None:
        raise HTTPException(status_code=401, detail="بەکارهێنەر نەدۆزرایەوە")
    return user

@app.get("/health")
def health():
    return {"status": "ok", "service": "SH BUSINESS OS API", "version": "3.0.0"}

@app.post("/auth/login", response_model=TokenOut)
def login(data: LoginIn, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == data.email.lower(), User.is_active == True))
    if user is None or not verify_password(data.password, user.password_hash):
        raise HTTPException(status_code=401, detail="ئیمەیڵ یان وشەی نهێنی هەڵەیە")
    return TokenOut(access_token=create_access_token(user.email), expires_in=settings.jwt_expire_minutes * 60)

@app.get("/auth/me", response_model=UserOut)
def me(user: User = Depends(current_user)):
    return user

@app.get("/accounts", response_model=list[AccountOut])
def list_accounts(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return list(db.scalars(select(Account).where(Account.is_active == True).order_by(Account.code)))

@app.post("/accounts", response_model=AccountOut, status_code=201)
def create_account(data: AccountIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    if db.scalar(select(Account).where(Account.code == data.code)):
        raise HTTPException(status_code=409, detail="کۆدی هەژمار پێشتر بەکارهاتووە")
    payload = data.model_dump()
    if payload.get("parent_id"):
        parent = db.get(Account, payload["parent_id"])
        if parent is None or not parent.is_group:
            raise HTTPException(status_code=422, detail="هەژماری باوان دەبێت هەژمارێکی گروپی چالاک بێت")
    if payload.get("is_group") and payload.get("currency"):
        raise HTTPException(status_code=422, detail="هەژماری گروپی نابێت دراوی تایبەتی هەبێت")
    account = Account(**payload)
    db.add(account)
    db.flush()
    audit(db, user.id, "account.created", "account", str(account.id), {"code": account.code, "name_ku": account.name_ku})
    db.commit()
    db.refresh(account)
    return account


@app.get("/accounts/chart")
def chart_of_accounts(db: Session = Depends(get_db), user: User = Depends(current_user)):
    accounts = db.scalars(select(Account).where(Account.is_active == True).order_by(Account.code)).all()
    return [
        {"id": a.id, "code": a.code, "name_ku": a.name_ku, "account_type": a.account_type,
         "currency": a.currency, "parent_id": a.parent_id, "normal_balance": a.normal_balance,
         "is_group": a.is_group, "is_active": a.is_active}
        for a in accounts
    ]

@app.post("/opening-balances", response_model=JournalOut, status_code=201)
def create_opening_balance(data: OpeningBalanceIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    existing = db.scalar(select(JournalEntry.id).where(
        JournalEntry.source_module == "opening_balance",
        JournalEntry.entry_date == data.effective_date,
        JournalEntry.status.in_(["draft", "posted"])
    ).limit(1))
    if existing:
        raise HTTPException(status_code=409, detail="بۆ ئەم بەروارە باڵانسی دەستپێک هەیە؛ پێش دروستکردنی تۆماری نوێ، تۆماری پێشووتر بپشکنە")
    try:
        validate_balanced_lines([line.model_dump() for line in data.lines])
    except AccountingValidationError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    period = db.scalar(select(AccountingPeriod).where(
        AccountingPeriod.starts_on <= data.effective_date,
        AccountingPeriod.ends_on >= data.effective_date,
        AccountingPeriod.status == "open"
    ))
    if period is None:
        raise HTTPException(status_code=422, detail="ماوەی ژمێریاری کراوە بۆ بەرواری باڵانسی دەستپێک نییە")
    account_ids = {line.account_id for line in data.lines}
    accounts = {a.id: a for a in db.scalars(select(Account).where(Account.id.in_(account_ids), Account.is_active == True)).all()}
    if len(accounts) != len(account_ids):
        raise HTTPException(status_code=422, detail="هەژمارێک نەدۆزرایەوە یان چالاک نییە")
    for line in data.lines:
        account = accounts[line.account_id]
        if account.is_group:
            raise HTTPException(status_code=422, detail=f"هەژماری {account.code} گروپییە و نابێت ڕاستەوخۆ تۆماری لەسەر بکرێت")
        if account.currency and account.currency != line.currency:
            raise HTTPException(status_code=422, detail=f"دراوی هەژماری {account.code} لەگەڵ دراوی هێڵەکە ناگونجێت")
    entry = JournalEntry(
        entry_no=f"OB-{data.effective_date.strftime('%Y%m%d')}-{secrets.token_hex(4)}",
        entry_date=data.effective_date, description_ku=data.description_ku,
        source_module="opening_balance", status="draft", period_id=period.id, created_by=user.id
    )
    entry.lines = [JournalLine(account_id=x.account_id, side=x.side, currency=x.currency, amount=x.amount, memo_ku=x.memo_ku) for x in data.lines]
    db.add(entry)
    db.flush()
    audit(db, user.id, "opening_balance.draft_created", "journal_entry", str(entry.id),
          {"entry_no": entry.entry_no, "effective_date": str(data.effective_date), "line_count": len(entry.lines)})
    db.commit()
    db.refresh(entry)
    return JournalOut(id=entry.id, entry_no=entry.entry_no, status=entry.status,
                      description_ku=entry.description_ku, entry_date=entry.entry_date)

@app.post("/opening-balances/validate")
def validate_opening_balance(data: OpeningBalanceIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    """Validate an opening-balance payload without creating a journal entry."""
    try:
        validate_balanced_lines([line.model_dump() for line in data.lines])
    except AccountingValidationError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    account_ids = {line.account_id for line in data.lines}
    accounts = {a.id: a for a in db.scalars(select(Account).where(
        Account.id.in_(account_ids), Account.is_active == True
    )).all()}
    if len(accounts) != len(account_ids):
        raise HTTPException(status_code=422, detail="هەژمارێک نەدۆزرایەوە یان چالاک نییە")
    for line in data.lines:
        account = accounts[line.account_id]
        if account.is_group:
            raise HTTPException(status_code=422, detail=f"هەژماری {account.code} گروپییە و نابێت ڕاستەوخۆ تۆماری لەسەر بکرێت")
        if account.currency and account.currency != line.currency:
            raise HTTPException(status_code=422, detail=f"دراوی هەژماری {account.code} لەگەڵ دراوی هێڵەکە ناگونجێت")
    totals = {}
    for line in data.lines:
        bucket = totals.setdefault(line.currency, {"debit": Decimal("0"), "credit": Decimal("0")})
        bucket[line.side] += Decimal(line.amount)
    return {
        "valid": True,
        "effective_date": str(data.effective_date),
        "line_count": len(data.lines),
        "currency_totals": {
            currency: {"debit": str(v["debit"]), "credit": str(v["credit"]),
                       "difference": str(v["debit"] - v["credit"])}
            for currency, v in sorted(totals.items())
        },
        "warning": "ئەمە تەنها پشکنینە؛ هیچ تۆمارێک دروست نەکراوە و هیچ دراوێک بۆ یەک ناگۆڕدرێت."
    }

@app.get("/opening-balances/summary")
def opening_balance_summary(db: Session = Depends(get_db), user: User = Depends(current_user)):
    entries = db.scalars(select(JournalEntry).where(
        JournalEntry.source_module == "opening_balance"
    ).order_by(JournalEntry.entry_date, JournalEntry.id)).all()
    result = []
    for entry in entries:
        totals = {}
        for line in entry.lines:
            bucket = totals.setdefault(line.currency, {"debit": Decimal("0"), "credit": Decimal("0")})
            bucket[line.side] += Decimal(line.amount)
        result.append({
            "id": entry.id, "entry_no": entry.entry_no, "date": str(entry.entry_date),
            "status": entry.status, "currencies": {
                c: {"debit": str(v["debit"]), "credit": str(v["credit"]),
                    "difference": str(v["debit"] - v["credit"])}
                for c, v in sorted(totals.items())
            }
        })
    return {"entries": result, "count": len(result)}

@app.post("/partners", response_model=PartnerOut, status_code=201)
def create_partner(data: PartnerIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    if db.scalar(select(Partner.id).where(Partner.partner_code == data.partner_code)):
        raise HTTPException(status_code=409, detail="کۆدی هاوبەش پێشتر بەکارهاتووە")
    partner = Partner(**data.model_dump())
    db.add(partner)
    db.flush()
    audit(db, user.id, "partner.created", "partner", str(partner.id),
          {"partner_code": partner.partner_code, "name": partner.name})
    db.commit()
    db.refresh(partner)
    return partner


@app.get("/partners", response_model=list[PartnerOut])
def list_partners(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return list(db.scalars(select(Partner).where(Partner.is_active == True).order_by(Partner.partner_code)))


@app.post("/capital-transactions", response_model=CapitalTransactionOut, status_code=201)
def create_capital_transaction(data: CapitalTransactionIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    partner = db.scalar(select(Partner).where(Partner.id == data.partner_id, Partner.is_active == True).with_for_update())
    if partner is None:
        raise HTTPException(status_code=404, detail="هاوبەش نەدۆزرایەوە یان چالاک نییە")
    if data.transaction_type == "withdrawal":
        rows = db.execute(
            select(CapitalTransaction.transaction_type, CapitalTransaction.amount)
            .where(CapitalTransaction.partner_id == data.partner_id,
                   CapitalTransaction.currency == data.currency)
        ).all()
        balance = sum((Decimal(a) if t == "contribution" else -Decimal(a) for t, a in rows), Decimal("0"))
        if data.amount > balance:
            raise HTTPException(status_code=422, detail=f"بڕی دەرکردن لە باڵانسی سەرمایەی ئەم هاوبەشە بە {data.currency} زیاترە")
    tx = CapitalTransaction(**data.model_dump(), created_by=user.id)
    db.add(tx)
    db.flush()
    audit(db, user.id, "capital.transaction_created", "capital_transaction", str(tx.id),
          {"partner_id": tx.partner_id, "type": tx.transaction_type,
           "currency": tx.currency, "amount": str(tx.amount)})
    db.commit()
    db.refresh(tx)
    return tx


@app.get("/capital-transactions", response_model=list[CapitalTransactionOut])
def list_capital_transactions(partner_id: int | None = None, db: Session = Depends(get_db),
                              user: User = Depends(current_user)):
    q = select(CapitalTransaction).order_by(CapitalTransaction.transaction_date.desc(), CapitalTransaction.id.desc())
    if partner_id is not None:
        q = q.where(CapitalTransaction.partner_id == partner_id)
    return list(db.scalars(q.limit(500)))


@app.get("/reports/partner-capital")
def partner_capital_report(db: Session = Depends(get_db), user: User = Depends(current_user)):
    rows = db.execute(
        select(CapitalTransaction.partner_id, Partner.partner_code, Partner.name,
               CapitalTransaction.currency, CapitalTransaction.transaction_type, CapitalTransaction.amount)
        .join(Partner, Partner.id == CapitalTransaction.partner_id)
    ).all()
    totals = {}
    for pid, code, name, currency, tx_type, amount in rows:
        key = (pid, code, name, currency)
        totals.setdefault(key, {"contributions": Decimal("0"), "withdrawals": Decimal("0")})
        bucket = "contributions" if tx_type == "contribution" else "withdrawals"
        totals[key][bucket] += Decimal(amount)
    return [
        {"partner_id": k[0], "partner_code": k[1], "partner_name": k[2], "currency": k[3],
         "contributions": str(v["contributions"]), "withdrawals": str(v["withdrawals"]),
         "capital_balance": str(v["contributions"] - v["withdrawals"])}
        for k, v in sorted(totals.items(), key=lambda x: (x[0][1], x[0][3]))
    ]


@app.post("/partner-loans", response_model=PartnerLoanOut, status_code=201)
def create_partner_loan(data: PartnerLoanIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    if data.due_date and data.due_date < data.loan_date:
        raise HTTPException(status_code=422, detail="بەرواری وادەی پارەدان نابێت پێش بەرواری وەرگرتنی قەرز بێت")
    partner = db.get(Partner, data.partner_id)
    if partner is None or not partner.is_active:
        raise HTTPException(status_code=404, detail="هاوبەش نەدۆزرایەوە یان چالاک نییە")
    loan = PartnerLoan(
        loan_no=f"PL-{data.loan_date.strftime('%Y%m%d')}-{secrets.token_hex(4)}",
        **data.model_dump(), created_by=user.id
    )
    db.add(loan)
    db.flush()
    audit(db, user.id, "partner_loan.created", "partner_loan", str(loan.id),
          {"partner_id": loan.partner_id, "currency": loan.currency,
           "principal": str(loan.principal_amount)})
    db.commit()
    db.refresh(loan)
    return PartnerLoanOut(
        id=loan.id, loan_no=loan.loan_no, partner_id=loan.partner_id,
        loan_date=loan.loan_date, currency=loan.currency,
        principal_amount=loan.principal_amount, due_date=loan.due_date,
        interest_rate=loan.interest_rate, status=loan.status,
        outstanding_amount=loan.principal_amount
    )


@app.get("/partner-loans", response_model=list[PartnerLoanOut])
def list_partner_loans(partner_id: int | None = None, db: Session = Depends(get_db),
                       user: User = Depends(current_user)):
    q = select(PartnerLoan).order_by(PartnerLoan.loan_date.desc(), PartnerLoan.id.desc())
    if partner_id is not None:
        q = q.where(PartnerLoan.partner_id == partner_id)
    loans = db.scalars(q.limit(500)).all()
    output = []
    for loan in loans:
        payments = db.scalars(select(PartnerLoanPayment.amount).where(PartnerLoanPayment.loan_id == loan.id)).all()
        outstanding = loan.principal_amount - sum((Decimal(x) for x in payments), Decimal("0"))
        output.append(PartnerLoanOut(
            id=loan.id, loan_no=loan.loan_no, partner_id=loan.partner_id,
            loan_date=loan.loan_date, currency=loan.currency,
            principal_amount=loan.principal_amount, due_date=loan.due_date,
            interest_rate=loan.interest_rate, status=loan.status,
            outstanding_amount=outstanding
        ))
    return output


@app.post("/partner-loans/{loan_id}/payments", status_code=201)
def pay_partner_loan(loan_id: int, data: PartnerLoanPaymentIn, db: Session = Depends(get_db),
                     user: User = Depends(current_user)):
    loan = db.scalar(select(PartnerLoan).where(PartnerLoan.id == loan_id).with_for_update())
    if loan is None:
        raise HTTPException(status_code=404, detail="قەرز نەدۆزرایەوە")
    if loan.status != "open":
        raise HTTPException(status_code=409, detail="ئەم قەرزە کراوە نییە")
    payments = db.scalars(select(PartnerLoanPayment.amount).where(PartnerLoanPayment.loan_id == loan.id)).all()
    outstanding = loan.principal_amount - sum((Decimal(x) for x in payments), Decimal("0"))
    if data.amount > outstanding:
        raise HTTPException(status_code=422, detail="بڕی پارەدان لە باڵانسی ماوەی قەرز زیاترە")
    payment = PartnerLoanPayment(loan_id=loan.id, **data.model_dump(), created_by=user.id)
    db.add(payment)
    db.flush()
    new_outstanding = outstanding - data.amount
    if new_outstanding == 0:
        loan.status = "settled"
    audit(db, user.id, "partner_loan.payment_created", "partner_loan_payment", str(payment.id),
          {"loan_id": loan.id, "currency": loan.currency, "amount": str(data.amount),
           "outstanding_after": str(new_outstanding)})
    db.commit()
    return {"id": payment.id, "loan_id": loan.id, "payment_date": str(payment.payment_date),
            "currency": loan.currency, "amount": str(payment.amount),
            "outstanding_amount": str(new_outstanding), "loan_status": loan.status}




def _source_journal_draft(db: Session, user: User, source_type: str, source_id: int,
                          entry_date: date, amount: Decimal, currency: str,
                          debit_account_id: int, credit_account_id: int, description: str):
    """Create a balanced, owner-reviewable draft; never posts automatically."""
    if db.scalar(select(JournalSourceLink.id).where(
        JournalSourceLink.source_type == source_type, JournalSourceLink.source_id == source_id
    )):
        raise HTTPException(status_code=409, detail="ئەم مامەڵەیە پێشتر بە تۆماری ژمێریارییەوە بەستراوەتەوە")
    period = db.scalar(select(AccountingPeriod).where(
        AccountingPeriod.starts_on <= entry_date, AccountingPeriod.ends_on >= entry_date,
        AccountingPeriod.status == "open"
    ))
    if period is None:
        raise HTTPException(status_code=422, detail="ماوەی ژمێریاری کراوە بۆ بەرواری ئەم مامەڵەیە نییە")
    ids = {debit_account_id, credit_account_id}
    accounts = {a.id: a for a in db.scalars(select(Account).where(
        Account.id.in_(ids), Account.is_active == True
    )).all()}
    if len(accounts) != 2:
        raise HTTPException(status_code=422, detail="هەردوو هەژماری دیاریکراو دەبێت چالاک بن")
    if debit_account_id == credit_account_id:
        raise HTTPException(status_code=422, detail="هەژماری بدهکار و بستانکار نابێت یەکسان بن")
    for account in accounts.values():
        if account.is_group:
            raise HTTPException(status_code=422, detail=f"هەژماری {account.code} گروپییە")
        if account.currency and account.currency != currency:
            raise HTTPException(status_code=422, detail=f"دراوی هەژماری {account.code} لەگەڵ مامەڵەکە ناگونجێت")
    debit_type = accounts[debit_account_id].account_type
    credit_type = accounts[credit_account_id].account_type
    if source_type == "capital_transaction":
        expected = ("asset", "equity") if debit_type == "asset" else ("equity", "asset")
        if (debit_type, credit_type) not in (("asset", "equity"), ("equity", "asset")):
            raise HTTPException(status_code=422, detail="مامەڵەی سەرمایە دەبێت لە نێوان هەژماری دارایی و سەرمایەدا بێت")
    elif source_type == "partner_loan":
        if (debit_type, credit_type) != ("asset", "liability"):
            raise HTTPException(status_code=422, detail="وەرگرتنی قەرز دەبێت: بدهکار دارایی، بستانکار لیابلیتی")
    elif source_type == "partner_loan_payment":
        if (debit_type, credit_type) != ("liability", "asset"):
            raise HTTPException(status_code=422, detail="پارەدانی قەرز دەبێت: بدهکار لیابلیتی، بستانکار دارایی")
    try:
        validate_balanced_lines([
            {"side": "debit", "currency": currency, "amount": amount},
            {"side": "credit", "currency": currency, "amount": amount},
        ])
    except AccountingValidationError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    entry = JournalEntry(
        entry_no=f"SRC-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f')}-{secrets.token_hex(2)}",
        entry_date=entry_date, description_ku=description, source_module=source_type,
        status="draft", period_id=period.id, created_by=user.id
    )
    entry.lines = [
        JournalLine(account_id=debit_account_id, side="debit", currency=currency, amount=amount, memo_ku=description),
        JournalLine(account_id=credit_account_id, side="credit", currency=currency, amount=amount, memo_ku=description),
    ]
    db.add(entry); db.flush()
    link = JournalSourceLink(source_type=source_type, source_id=source_id,
                             journal_entry_id=entry.id, created_by=user.id)
    db.add(link)
    audit(db, user.id, "source_journal.draft_created", source_type, str(source_id),
          {"journal_entry_id": entry.id, "currency": currency, "amount": str(amount)})
    db.commit(); db.refresh(entry)
    return JournalOut(id=entry.id, entry_no=entry.entry_no, status=entry.status,
                      description_ku=entry.description_ku, entry_date=entry.entry_date)


@app.post("/capital-transactions/{transaction_id}/journal-draft", response_model=JournalOut, status_code=201)
def capital_transaction_journal_draft(transaction_id: int, data: SourceJournalDraftIn,
                                      db: Session = Depends(get_db), user: User = Depends(current_user)):
    tx = db.get(CapitalTransaction, transaction_id)
    if tx is None: raise HTTPException(status_code=404, detail="مامەڵەی سەرمایە نەدۆزرایەوە")
    debit, credit = ((data.cash_account_id, data.offset_account_id) if tx.transaction_type == "contribution"
                     else (data.offset_account_id, data.cash_account_id))
    return _source_journal_draft(db, user, "capital_transaction", tx.id, tx.transaction_date,
                                 tx.amount, tx.currency, debit, credit,
                                 f"سەرمایەی هاوبەش #{tx.partner_id} - {tx.transaction_type}")


@app.post("/partner-loans/{loan_id}/journal-draft", response_model=JournalOut, status_code=201)
def partner_loan_journal_draft(loan_id: int, data: SourceJournalDraftIn,
                               db: Session = Depends(get_db), user: User = Depends(current_user)):
    loan = db.get(PartnerLoan, loan_id)
    if loan is None: raise HTTPException(status_code=404, detail="قەرز نەدۆزرایەوە")
    return _source_journal_draft(db, user, "partner_loan", loan.id, loan.loan_date,
                                 loan.principal_amount, loan.currency, data.cash_account_id,
                                 data.offset_account_id, f"وەرگرتنی قەرز {loan.loan_no}")


@app.post("/partner-loan-payments/{payment_id}/journal-draft", response_model=JournalOut, status_code=201)
def partner_loan_payment_journal_draft(payment_id: int, data: SourceJournalDraftIn,
                                       db: Session = Depends(get_db), user: User = Depends(current_user)):
    payment = db.get(PartnerLoanPayment, payment_id)
    if payment is None: raise HTTPException(status_code=404, detail="پارەدانی قەرز نەدۆزرایەوە")
    loan = db.get(PartnerLoan, payment.loan_id)
    return _source_journal_draft(db, user, "partner_loan_payment", payment.id, payment.payment_date,
                                 payment.amount, loan.currency, data.offset_account_id,
                                 data.cash_account_id, f"پارەدانی قەرز {loan.loan_no}")




@app.post("/properties", response_model=PropertyDealOut, status_code=201)
def create_property_deal(data: PropertyDealIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    if db.scalar(select(PropertyDeal.id).where(PropertyDeal.deal_code == data.deal_code)):
        raise HTTPException(status_code=409, detail="کۆدی مامەڵەی زەوی پێشتر بەکارهاتووە")
    deal = PropertyDeal(**data.model_dump(), created_by=user.id)
    db.add(deal)
    db.flush()
    audit(db, user.id, "property.deal_created", "property_deal", str(deal.id),
          {"deal_code": deal.deal_code, "currency": deal.currency, "purchase_price": str(deal.purchase_price)})
    db.commit()
    db.refresh(deal)
    return deal


@app.get("/properties", response_model=list[PropertyDealOut])
def list_property_deals(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return list(db.scalars(select(PropertyDeal).order_by(PropertyDeal.purchase_date.desc(), PropertyDeal.id.desc()).limit(500)))


@app.post("/properties/{deal_id}/participants", status_code=201)
def add_property_participant(deal_id: int, data: PropertyParticipantIn,
                             db: Session = Depends(get_db), user: User = Depends(current_user)):
    deal = db.scalar(select(PropertyDeal).where(PropertyDeal.id == deal_id).with_for_update())
    if deal is None:
        raise HTTPException(status_code=404, detail="مامەڵەی زەوی نەدۆزرایەوە")
    if deal.status != "open":
        raise HTTPException(status_code=409, detail="تەنها مامەڵەی کراوە دەتوانرێت دەستکاری بکرێت")
    if data.currency != deal.currency:
        raise HTTPException(status_code=422, detail="دراوی بەشداری دەبێت هەمان دراوی مامەڵەکە بێت")
    if data.partner_id is not None and db.get(Partner, data.partner_id) is None:
        raise HTTPException(status_code=404, detail="هاوبەشی گشتی نەدۆزرایەوە")
    row = PropertyParticipant(deal_id=deal_id, **data.model_dump())
    db.add(row)
    db.flush()
    audit(db, user.id, "property.participant_added", "property_participant", str(row.id),
          {"deal_id": deal_id, "name": row.participant_name,
           "contribution": str(row.contribution_amount), "legal_ownership_percent": str(row.legal_ownership_percent),
           "profit_share_percent": str(row.profit_share_percent)})
    db.commit()
    db.refresh(row)
    return row


@app.get("/properties/{deal_id}/participants")
def list_property_participants(deal_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    if db.get(PropertyDeal, deal_id) is None:
        raise HTTPException(status_code=404, detail="مامەڵەی زەوی نەدۆزرایەوە")
    rows = db.scalars(select(PropertyParticipant).where(PropertyParticipant.deal_id == deal_id).order_by(PropertyParticipant.id))
    return [{"id": x.id, "participant_name": x.participant_name, "participant_type": x.participant_type,
             "partner_id": x.partner_id, "contribution_amount": str(x.contribution_amount), "currency": x.currency,
             "legal_ownership_percent": str(x.legal_ownership_percent) if x.legal_ownership_percent is not None else None,
             "profit_share_percent": str(x.profit_share_percent) if x.profit_share_percent is not None else None,
             "agreement_ref": x.agreement_ref, "notes": x.notes} for x in rows]


@app.post("/properties/{deal_id}/expenses", status_code=201)
def add_property_expense(deal_id: int, data: PropertyExpenseIn,
                         db: Session = Depends(get_db), user: User = Depends(current_user)):
    deal = db.scalar(select(PropertyDeal).where(PropertyDeal.id == deal_id).with_for_update())
    if deal is None:
        raise HTTPException(status_code=404, detail="مامەڵەی زەوی نەدۆزرایەوە")
    if deal.status != "open" or data.currency != deal.currency:
        raise HTTPException(status_code=422, detail="مامەڵەکە دەبێت کراوە بێت و دراوی خەرجی لەگەڵ دراوی مامەڵەکە یەک بێت")
    row = PropertyExpense(deal_id=deal_id, created_by=user.id, **data.model_dump())
    db.add(row)
    db.flush()
    audit(db, user.id, "property.expense_added", "property_expense", str(row.id), {"deal_id": deal_id, "amount": str(row.amount)})
    db.commit()
    db.refresh(row)
    return {"id": row.id, "deal_id": row.deal_id, "expense_date": row.expense_date,
            "category": row.category, "amount": str(row.amount), "currency": row.currency}


@app.post("/properties/{deal_id}/sale", status_code=201)
def record_property_sale(deal_id: int, data: PropertySaleIn,
                         db: Session = Depends(get_db), user: User = Depends(current_user)):
    deal = db.scalar(select(PropertyDeal).where(PropertyDeal.id == deal_id).with_for_update())
    if deal is None:
        raise HTTPException(status_code=404, detail="مامەڵەی زەوی نەدۆزرایەوە")
    if deal.status != "open":
        raise HTTPException(status_code=409, detail="مامەڵەکە پێشتر داخراوە یان فرۆشراوە")
    if data.currency != deal.currency or data.received_amount > data.sale_amount:
        raise HTTPException(status_code=422, detail="دراوی فرۆشتن دەبێت یەکسان بێت و پارەی وەرگیراو لە کۆی فرۆشتن زیاتر نەبێت")
    row = PropertySale(deal_id=deal_id, created_by=user.id, **data.model_dump())
    deal.status = "sold"
    db.add(row)
    db.flush()
    audit(db, user.id, "property.sold", "property_deal", str(deal_id),
          {"sale_amount": str(row.sale_amount), "received_amount": str(row.received_amount), "currency": row.currency})
    db.commit()
    db.refresh(row)
    return {"id": row.id, "deal_id": row.deal_id, "sale_date": row.sale_date,
            "sale_amount": str(row.sale_amount), "received_amount": str(row.received_amount),
            "receivable": str(row.sale_amount - row.received_amount), "currency": row.currency}


@app.post("/properties/{deal_id}/payments", status_code=201)
def add_property_payment(deal_id: int, data: PropertyPaymentIn,
                         db: Session = Depends(get_db), user: User = Depends(current_user)):
    deal = db.scalar(select(PropertyDeal).where(PropertyDeal.id == deal_id).with_for_update())
    if deal is None:
        raise HTTPException(status_code=404, detail="مامەڵەی زەوی نەدۆزرایەوە")
    if data.currency != deal.currency:
        raise HTTPException(status_code=422, detail="دراوی پارەدان دەبێت لەگەڵ دراوی مامەڵەکە یەک بێت")
    if data.payment_type == "participant_contribution":
        if data.participant_id is None:
            raise HTTPException(status_code=422, detail="بەشداری دارایی پێویستی بە دیاریکردنی بەشداربوو هەیە")
        participant = db.scalar(select(PropertyParticipant).where(
            PropertyParticipant.id == data.participant_id, PropertyParticipant.deal_id == deal_id))
        if participant is None:
            raise HTTPException(status_code=404, detail="بەشداربووی ئەم مامەڵەیە نەدۆزرایەوە")
        paid = sum((Decimal(x.amount) for x in db.scalars(select(PropertyPayment).where(
            PropertyPayment.participant_id == participant.id, PropertyPayment.payment_type == "participant_contribution"))), Decimal("0"))
        if paid + data.amount > Decimal(participant.contribution_amount):
            raise HTTPException(status_code=422, detail="کۆی پارەی بەشداری لە بڕی ڕێککەوتنی بەشداری زیاترە")
    elif data.participant_id is not None:
        raise HTTPException(status_code=422, detail="بەشداربوو تەنها بۆ پارەی بەشداری دارایی دیاری دەکرێت")
    elif data.payment_type == "purchase_payment":
        paid = sum((Decimal(x.amount) for x in db.scalars(select(PropertyPayment).where(
            PropertyPayment.deal_id == deal_id, PropertyPayment.payment_type == "purchase_payment"))), Decimal("0"))
        if paid + data.amount > Decimal(deal.purchase_price):
            raise HTTPException(status_code=422, detail="کۆی پارەی دراو بۆ کڕین لە نرخی کڕین زیاترە")
    else:
        sale = db.scalar(select(PropertySale).where(PropertySale.deal_id == deal_id))
        if sale is None:
            raise HTTPException(status_code=409, detail="پێش تۆمارکردنی وەرگرتنی پارە، فرۆشتن تۆمار بکە")
        received = sum((Decimal(x.amount) for x in db.scalars(select(PropertyPayment).where(
            PropertyPayment.deal_id == deal_id, PropertyPayment.payment_type == "sale_receipt"))), Decimal(sale.received_amount))
        if received + data.amount > Decimal(sale.sale_amount):
            raise HTTPException(status_code=422, detail="کۆی پارەی وەرگیراو لە نرخی فرۆشتن زیاترە")
    row = PropertyPayment(deal_id=deal_id, created_by=user.id, **data.model_dump())
    db.add(row)
    db.flush()
    audit(db, user.id, "property.payment_recorded", "property_payment", str(row.id),
          {"deal_id": deal_id, "type": row.payment_type, "amount": str(row.amount), "currency": row.currency})
    db.commit()
    db.refresh(row)
    return {"id": row.id, "deal_id": row.deal_id, "participant_id": row.participant_id,
            "payment_type": row.payment_type, "payment_date": row.payment_date,
            "amount": str(row.amount), "currency": row.currency, "reference": row.reference}


@app.get("/properties/{deal_id}/payments")
def list_property_payments(deal_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    if db.get(PropertyDeal, deal_id) is None:
        raise HTTPException(status_code=404, detail="مامەڵەی زەوی نەدۆزرایەوە")
    rows = db.scalars(select(PropertyPayment).where(PropertyPayment.deal_id == deal_id).order_by(PropertyPayment.payment_date, PropertyPayment.id))
    return [{"id": x.id, "participant_id": x.participant_id, "payment_type": x.payment_type,
             "payment_date": x.payment_date, "amount": str(x.amount), "currency": x.currency,
             "reference": x.reference, "notes": x.notes} for x in rows]


@app.get("/properties/{deal_id}/report")
def property_deal_report(deal_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    deal = db.get(PropertyDeal, deal_id)
    if deal is None:
        raise HTTPException(status_code=404, detail="مامەڵەی زەوی نەدۆزرایەوە")
    expenses = list(db.scalars(select(PropertyExpense).where(PropertyExpense.deal_id == deal_id)))
    participants = list(db.scalars(select(PropertyParticipant).where(PropertyParticipant.deal_id == deal_id)))
    sale = db.scalar(select(PropertySale).where(PropertySale.deal_id == deal_id))
    total_expenses = sum((Decimal(x.amount) for x in expenses), Decimal("0"))
    gross_sale = Decimal(sale.sale_amount) if sale else Decimal("0")
    payment_rows = list(db.scalars(select(PropertyPayment).where(PropertyPayment.deal_id == deal_id)))
    purchase_paid = sum((Decimal(x.amount) for x in payment_rows if x.payment_type == "purchase_payment"), Decimal("0"))
    sale_receipts = sum((Decimal(x.amount) for x in payment_rows if x.payment_type == "sale_receipt"), Decimal(sale.received_amount) if sale else Decimal("0"))
    participant_paid = sum((Decimal(x.amount) for x in payment_rows if x.payment_type == "participant_contribution"), Decimal("0"))
    net_result = gross_sale - Decimal(deal.purchase_price) - total_expenses if sale else None
    legal_total = sum((Decimal(x.legal_ownership_percent) for x in participants if x.legal_ownership_percent is not None), Decimal("0"))
    profit_total = sum((Decimal(x.profit_share_percent) for x in participants if x.profit_share_percent is not None), Decimal("0"))
    allocations = []
    if net_result is not None:
        for x in participants:
            allocations.append({"participant_name": x.participant_name,
                "profit_share_percent": str(x.profit_share_percent) if x.profit_share_percent is not None else None,
                "profit_allocation": str((net_result * Decimal(x.profit_share_percent) / Decimal("100"))) if x.profit_share_percent is not None else None})
    return {"deal_id": deal.id, "deal_code": deal.deal_code, "status": deal.status, "currency": deal.currency,
            "purchase_price": str(deal.purchase_price), "total_expenses": str(total_expenses),
            "sale_amount": str(gross_sale) if sale else None,
            "sale_received": str(sale_receipts) if sale else None,
            "sale_receivable": str(Decimal(sale.sale_amount) - sale_receipts) if sale else None,
            "purchase_paid": str(purchase_paid), "purchase_payable": str(max(Decimal("0"), Decimal(deal.purchase_price) - purchase_paid)),
            "participant_contributions_received": str(participant_paid),
            "net_result": str(net_result) if net_result is not None else None,
            "legal_ownership_total_percent": str(legal_total), "profit_share_total_percent": str(profit_total),
            "legal_ownership_configured_to_100": legal_total == Decimal("100"),
            "profit_share_configured_to_100": profit_total == Decimal("100"),
            "profit_allocations": allocations,
            "warning": "ڕێژەی خاوەندارێتی و قازانج بە بەشداری داراییەوە هەژمار نەکراون؛ بەڵگە و ڕێککەوتنی یاسایی پشکنین بکە"}


@app.get("/accounting-periods", response_model=list[PeriodOut])
def list_periods(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return list(db.scalars(select(AccountingPeriod).order_by(AccountingPeriod.starts_on.desc())))

@app.post("/accounting-periods", response_model=PeriodOut, status_code=201)
def create_period(data: PeriodIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    if data.ends_on < data.starts_on:
        raise HTTPException(status_code=422, detail="کۆتایی ماوە نابێت پێش دەستپێک بێت")
    if db.scalar(select(AccountingPeriod).where(AccountingPeriod.name == data.name)):
        raise HTTPException(status_code=409, detail="ناوی ماوەی ژمێریاری دووبارەیە")
    overlap = db.scalar(select(AccountingPeriod).where(
        AccountingPeriod.starts_on <= data.ends_on,
        AccountingPeriod.ends_on >= data.starts_on
    ))
    if overlap:
        raise HTTPException(status_code=409, detail="ماوەی ژمێریاری لەگەڵ ماوەیەکی تر تێکەڵ دەبێت")
    period = AccountingPeriod(name=data.name, starts_on=data.starts_on, ends_on=data.ends_on)
    db.add(period)
    db.flush()
    audit(db, user.id, "period.created", "accounting_period", str(period.id), data.model_dump())
    db.commit()
    db.refresh(period)
    return period

@app.post("/accounting-periods/{period_id}/close", response_model=PeriodOut)
def close_period(period_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    period = db.get(AccountingPeriod, period_id)
    if period is None:
        raise HTTPException(status_code=404, detail="ماوەی ژمێریاری نەدۆزرایەوە")
    if period.status == "closed":
        raise HTTPException(status_code=409, detail="ماوەکە پێشتر داخراوە")
    drafts = db.scalar(select(JournalEntry.id).where(JournalEntry.period_id == period_id, JournalEntry.status == "draft").limit(1))
    if drafts:
        raise HTTPException(status_code=409, detail="پێش داخستن، مامەڵە ڕەشنووسەکان پەسەند بکە یان لاببە")
    period.status = "closed"
    audit(db, user.id, "period.closed", "accounting_period", str(period.id), {"name": period.name})
    db.commit()
    db.refresh(period)
    return period

@app.get("/journal-entries", response_model=list[JournalOut])
def list_entries(db: Session = Depends(get_db), user: User = Depends(current_user)):
    entries = db.scalars(select(JournalEntry).order_by(JournalEntry.id.desc()).limit(200)).all()
    return [JournalOut(id=e.id, entry_no=e.entry_no, status=e.status, description_ku=e.description_ku, entry_date=e.entry_date) for e in entries]

@app.post("/journal-entries", response_model=JournalOut, status_code=201)
def create_entry(data: JournalIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    try:
        validate_balanced_lines([line.model_dump() for line in data.lines])
    except AccountingValidationError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    period = db.scalar(select(AccountingPeriod).where(
        AccountingPeriod.starts_on <= data.entry_date,
        AccountingPeriod.ends_on >= data.entry_date,
        AccountingPeriod.status == "open"
    ))
    if period is None:
        raise HTTPException(status_code=422, detail="هیچ ماوەیەکی ژمێریاری کراوە بۆ ئەم بەروارە نییە")
    account_ids = {line.account_id for line in data.lines}
    accounts = {a.id: a for a in db.scalars(select(Account).where(Account.id.in_(account_ids), Account.is_active == True)).all()}
    if len(accounts) != len(account_ids):
        raise HTTPException(status_code=422, detail="هەژمارێک نەدۆزرایەوە یان چالاک نییە")
    for line in data.lines:
        account = accounts[line.account_id]
        if account.is_group:
            raise HTTPException(status_code=422, detail=f"هەژماری {account.code} گروپییە و نابێت ڕاستەوخۆ تۆماری لەسەر بکرێت")
        if account.currency and account.currency != line.currency:
            raise HTTPException(status_code=422, detail=f"دراوی هەژماری {account.code} لەگەڵ دراوی هێڵەکە ناگونجێت")
    entry = JournalEntry(
        entry_no=f"JE-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S%f')}-{secrets.token_hex(2)}",
        entry_date=data.entry_date, description_ku=data.description_ku,
        source_module=data.source_module, status="draft", period_id=period.id, created_by=user.id
    )
    entry.lines = [JournalLine(account_id=x.account_id, side=x.side, currency=x.currency, amount=x.amount, memo_ku=x.memo_ku) for x in data.lines]
    db.add(entry)
    db.flush()
    audit(db, user.id, "journal.draft_created", "journal_entry", str(entry.id),
          {"entry_no": entry.entry_no, "source_module": entry.source_module, "line_count": len(entry.lines)})
    db.commit()
    db.refresh(entry)
    return JournalOut(id=entry.id, entry_no=entry.entry_no, status=entry.status,
                      description_ku=entry.description_ku, entry_date=entry.entry_date)

@app.post("/journal-entries/{entry_id}/post", response_model=JournalOut)
def post_entry(entry_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    entry = db.get(JournalEntry, entry_id)
    if entry is None:
        raise HTTPException(status_code=404, detail="مامەڵە نەدۆزرایەوە")
    if entry.status != "draft":
        raise HTTPException(status_code=409, detail="تەنها مامەڵەی ڕەشنووس دەتوانرێت پەسەند بکرێت")
    period = db.get(AccountingPeriod, entry.period_id)
    if period is None or period.status != "open":
        raise HTTPException(status_code=409, detail="ماوەی ژمێریاری داخراوە")
    try:
        validate_balanced_lines([{"side": x.side, "currency": x.currency, "amount": x.amount} for x in entry.lines])
    except AccountingValidationError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    entry.status = "posted"
    entry.posted_by = user.id
    entry.posted_at = datetime.now(timezone.utc)
    audit(db, user.id, "journal.posted", "journal_entry", str(entry.id), {"entry_no": entry.entry_no})
    db.commit()
    db.refresh(entry)
    return JournalOut(id=entry.id, entry_no=entry.entry_no, status=entry.status,
                      description_ku=entry.description_ku, entry_date=entry.entry_date)

@app.post("/journal-entries/{entry_id}/reverse", response_model=JournalOut, status_code=201)
def reverse_entry(entry_id: int, db: Session = Depends(get_db), user: User = Depends(current_user)):
    original = db.get(JournalEntry, entry_id)
    if original is None:
        raise HTTPException(status_code=404, detail="مامەڵە نەدۆزرایەوە")
    if original.status != "posted":
        raise HTTPException(status_code=409, detail="تەنها مامەڵەی پەسەندکراو دەتوانرێت هەڵبوەشێندرێتەوە")
    if db.scalar(select(JournalEntry.id).where(JournalEntry.reversal_of_id == original.id)):
        raise HTTPException(status_code=409, detail="ئەم مامەڵەیە پێشتر هەڵوەشێنراوەتەوە")
    today = date.today()
    period = db.scalar(select(AccountingPeriod).where(
        AccountingPeriod.starts_on <= today, AccountingPeriod.ends_on >= today,
        AccountingPeriod.status == "open"
    ))
    if period is None:
        raise HTTPException(status_code=409, detail="ماوەی ژمێریاری کراوە بۆ بەرواری ئەمڕۆ نییە")
    reversal = JournalEntry(
        entry_no=f"REV-{original.entry_no}-{secrets.token_hex(2)}",
        entry_date=today, description_ku=f"هەڵوەشاندنەوەی {original.entry_no}",
        source_module="reversal", status="posted", period_id=period.id,
        created_by=user.id, posted_by=user.id, posted_at=datetime.now(timezone.utc),
        reversal_of_id=original.id
    )
    reversal.lines = [
        JournalLine(account_id=x.account_id,
                    side="credit" if x.side == "debit" else "debit",
                    currency=x.currency, amount=x.amount,
                    memo_ku=f"Reversal: {x.memo_ku or ''}")
        for x in original.lines
    ]
    original.status = "reversed"
    db.add(reversal)
    db.flush()
    audit(db, user.id, "journal.reversed", "journal_entry", str(original.id),
          {"reversal_entry_id": reversal.id, "reversal_entry_no": reversal.entry_no})
    db.commit()
    db.refresh(reversal)
    return JournalOut(id=reversal.id, entry_no=reversal.entry_no, status=reversal.status,
                      description_ku=reversal.description_ku, entry_date=reversal.entry_date)

@app.get("/reports/trial-balance")
def trial_balance(db: Session = Depends(get_db), user: User = Depends(current_user)):
    rows = db.execute(
        select(Account.id, Account.code, Account.name_ku, JournalLine.currency,
               JournalLine.side, JournalLine.amount)
        .join(JournalLine, JournalLine.account_id == Account.id)
        .join(JournalEntry, JournalEntry.id == JournalLine.entry_id)
        .where(JournalEntry.status.in_(["posted", "reversed"]))
    ).all()
    totals = {}
    for account_id, code, name, currency, side, amount in rows:
        key = (account_id, code, name, currency)
        if key not in totals:
            totals[key] = {"debit": Decimal("0"), "credit": Decimal("0")}
        totals[key][side] += Decimal(amount)
    return [
        {"account_id": k[0], "code": k[1], "name_ku": k[2], "currency": k[3],
         "debit": str(v["debit"]), "credit": str(v["credit"]),
         "net_debit": str(v["debit"] - v["credit"])}
        for k, v in sorted(totals.items(), key=lambda item: (item[0][1], item[0][3]))
    ]


# v3.0 — consolidated operational modules
@app.post("/commodity-trades", status_code=201)
def create_commodity_trade(data: CommodityTradeIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    if db.scalar(select(CommodityTrade.id).where(CommodityTrade.trade_no == data.trade_no)):
        raise HTTPException(status_code=409, detail="ژمارەی مامەڵە دووبارەیە")
    row = CommodityTrade(**data.model_dump(), created_by=user.id)
    db.add(row); db.flush()
    audit(db, user.id, "commodity_trade.created", "commodity_trade", str(row.id), {"trade_no": row.trade_no, "type": row.commodity_type, "direction": row.direction})
    db.commit(); db.refresh(row)
    return {"id": row.id, "trade_no": row.trade_no, "commodity_type": row.commodity_type, "direction": row.direction, "trade_date": row.trade_date, "quantity": str(row.quantity), "unit": row.unit, "unit_price": str(row.unit_price), "extra_cost": str(row.extra_cost), "currency": row.currency, "gross_total": str(row.quantity * row.unit_price), "total_cost_or_proceeds": str(row.quantity * row.unit_price + (row.extra_cost if row.direction == "purchase" else -row.extra_cost))}

@app.get("/commodity-trades")
def list_commodity_trades(commodity_type: str | None = None, db: Session = Depends(get_db), user: User = Depends(current_user)):
    q = select(CommodityTrade).order_by(CommodityTrade.trade_date.desc(), CommodityTrade.id.desc())
    if commodity_type:
        if commodity_type not in ("fuel", "gold", "silver"): raise HTTPException(status_code=422, detail="جۆری کاڵا هەڵەیە")
        q = q.where(CommodityTrade.commodity_type == commodity_type)
    rows = db.scalars(q.limit(500)).all()
    return [{"id": r.id, "trade_no": r.trade_no, "commodity_type": r.commodity_type, "direction": r.direction, "trade_date": r.trade_date, "counterparty": r.counterparty, "quantity": str(r.quantity), "unit": r.unit, "unit_price": str(r.unit_price), "currency": r.currency, "extra_cost": str(r.extra_cost)} for r in rows]

@app.post("/external-investments", status_code=201)
def create_external_investment(data: ExternalInvestmentIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    if db.scalar(select(ExternalInvestment.id).where(ExternalInvestment.investment_code == data.investment_code)):
        raise HTTPException(status_code=409, detail="کۆدی وەبەرهێنان دووبارەیە")
    row = ExternalInvestment(**data.model_dump(), created_by=user.id)
    db.add(row); db.flush(); audit(db, user.id, "external_investment.created", "external_investment", str(row.id), {"code": row.investment_code})
    db.commit(); db.refresh(row)
    return {"id": row.id, "investment_code": row.investment_code, "company_name": row.company_name, "invested_amount": str(row.invested_amount), "currency": row.currency, "status": row.status}

@app.get("/external-investments")
def list_external_investments(db: Session = Depends(get_db), user: User = Depends(current_user)):
    rows = db.scalars(select(ExternalInvestment).order_by(ExternalInvestment.id.desc())).all()
    out=[]
    for r in rows:
        income = db.scalars(select(ExternalInvestmentIncome).where(ExternalInvestmentIncome.investment_id == r.id)).all()
        total = sum((Decimal(x.amount) for x in income if x.currency == r.currency), Decimal("0"))
        out.append({"id":r.id,"investment_code":r.investment_code,"company_name":r.company_name,"invested_amount":str(r.invested_amount),"currency":r.currency,"ownership_percent":str(r.ownership_percent) if r.ownership_percent is not None else None,"income_total_same_currency":str(total),"status":r.status})
    return out

@app.post("/external-investments/{investment_id}/income", status_code=201)
def add_external_income(investment_id: int, data: ExternalIncomeIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    inv = db.get(ExternalInvestment, investment_id)
    if inv is None: raise HTTPException(status_code=404, detail="وەبەرهێنان نەدۆزرایەوە")
    if inv.currency != data.currency: raise HTTPException(status_code=422, detail="دراوی داهات دەبێت لەگەڵ دراوی وەبەرهێنان یەکسان بێت؛ ئاڵوگۆڕی دراو بە تۆماری FX جیاواز ئەنجام بدە")
    row=ExternalInvestmentIncome(investment_id=investment_id, created_by=user.id, **data.model_dump())
    db.add(row); db.flush(); audit(db,user.id,"external_income.created","external_investment_income",str(row.id),{"investment_id":investment_id,"amount":str(row.amount)})
    db.commit(); db.refresh(row)
    return {"id":row.id,"investment_id":row.investment_id,"income_date":row.income_date,"amount":str(row.amount),"currency":row.currency,"period_label":row.period_label}

@app.post("/inventory/items", status_code=201)
def create_inventory_item(data: InventoryItemIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    if db.scalar(select(InventoryItem.id).where(InventoryItem.sku == data.sku)): raise HTTPException(status_code=409, detail="SKU دووبارەیە")
    row=InventoryItem(**data.model_dump()); db.add(row); db.flush(); audit(db,user.id,"inventory_item.created","inventory_item",str(row.id),{"sku":row.sku})
    db.commit(); db.refresh(row)
    return {"id":row.id,"sku":row.sku,"name":row.name,"category":row.category,"unit":row.unit,"reorder_level":str(row.reorder_level)}

@app.get("/inventory/items")
def list_inventory_items(db: Session = Depends(get_db), user: User = Depends(current_user)):
    items=db.scalars(select(InventoryItem).where(InventoryItem.is_active == True).order_by(InventoryItem.sku)).all(); out=[]
    for item in items:
        moves=db.scalars(select(InventoryMovement).where(InventoryMovement.item_id == item.id)).all()
        qty=sum((Decimal(m.quantity) if m.movement_type == "in" else -Decimal(m.quantity) if m.movement_type == "out" else Decimal(m.quantity) for m in moves), Decimal("0"))
        out.append({"id":item.id,"sku":item.sku,"name":item.name,"category":item.category,"unit":item.unit,"on_hand":str(qty),"reorder_level":str(item.reorder_level),"below_reorder":qty <= item.reorder_level})
    return out

@app.post("/inventory/movements", status_code=201)
def create_inventory_movement(data: InventoryMovementIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    item=db.get(InventoryItem,data.item_id)
    if item is None or not item.is_active: raise HTTPException(status_code=404, detail="کاڵای کۆگا نەدۆزرایەوە")
    if data.movement_type == "out":
        moves=db.scalars(select(InventoryMovement).where(InventoryMovement.item_id == item.id)).all()
        on_hand=sum((Decimal(m.quantity) if m.movement_type == "in" else -Decimal(m.quantity) if m.movement_type == "out" else Decimal(m.quantity) for m in moves), Decimal("0"))
        if data.quantity > on_hand: raise HTTPException(status_code=422, detail="بڕی دەرچوون لە بڕی بەردەست زیاترە")
    row=InventoryMovement(**data.model_dump(),created_by=user.id); db.add(row); db.flush(); audit(db,user.id,"inventory_movement.created","inventory_movement",str(row.id),{"item_id":item.id,"type":row.movement_type,"quantity":str(row.quantity)})
    db.commit(); db.refresh(row)
    return {"id":row.id,"item_id":row.item_id,"movement_type":row.movement_type,"quantity":str(row.quantity),"movement_date":row.movement_date}

@app.post("/cash-bank/movements", status_code=201)
def create_cash_bank_movement(data: CashBankMovementIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    account=db.get(Account,data.account_id)
    if account is None or not account.is_active or account.is_group: raise HTTPException(status_code=422,detail="هەژماری کاش/بانک نادروستە")
    if account.account_type != "asset" or (account.currency and account.currency != data.currency): raise HTTPException(status_code=422,detail="جۆر یان دراوی هەژمار لەگەڵ مامەڵەکە ناگونجێت")
    row=CashBankMovement(**data.model_dump(),created_by=user.id); db.add(row); db.flush(); audit(db,user.id,"cash_bank_movement.created","cash_bank_movement",str(row.id),{"account_id":row.account_id,"direction":row.direction,"amount":str(row.amount),"currency":row.currency})
    db.commit(); db.refresh(row)
    return {"id":row.id,"movement_date":row.movement_date,"account_id":row.account_id,"direction":row.direction,"amount":str(row.amount),"currency":row.currency,"category":row.category,"journal_status":"not_posted"}

@app.get("/cash-bank/movements")
def list_cash_bank_movements(db: Session = Depends(get_db), user: User = Depends(current_user)):
    rows=db.scalars(select(CashBankMovement).order_by(CashBankMovement.movement_date.desc(),CashBankMovement.id.desc()).limit(500)).all()
    return [{"id":r.id,"movement_date":r.movement_date,"account_id":r.account_id,"direction":r.direction,"amount":str(r.amount),"currency":r.currency,"category":r.category,"reference":r.reference} for r in rows]
