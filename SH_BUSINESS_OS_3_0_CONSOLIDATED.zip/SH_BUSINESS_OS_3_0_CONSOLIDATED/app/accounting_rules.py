from collections import defaultdict
from decimal import Decimal
from typing import Iterable

class AccountingValidationError(ValueError):
    pass

def validate_balanced_lines(lines: Iterable[dict]) -> None:
    """
    Validate double-entry totals independently for each currency.
    Each line must contain side, currency and positive Decimal amount.
    """
    totals = defaultdict(lambda: {"debit": Decimal("0"), "credit": Decimal("0")})
    count = 0
    for line in lines:
        count += 1
        side = line["side"]
        currency = line["currency"]
        amount = Decimal(str(line["amount"]))
        if side not in ("debit", "credit"):
            raise AccountingValidationError("side must be debit or credit")
        if currency not in ("USD", "IQD"):
            raise AccountingValidationError("unsupported currency")
        if amount <= 0:
            raise AccountingValidationError("amount must be positive")
        totals[currency][side] += amount
    if count < 2:
        raise AccountingValidationError("at least two journal lines are required")
    for currency, sides in totals.items():
        if sides["debit"] != sides["credit"]:
            raise AccountingValidationError(f"unbalanced journal entry for {currency}")
    if not totals:
        raise AccountingValidationError("journal entry has no lines")
