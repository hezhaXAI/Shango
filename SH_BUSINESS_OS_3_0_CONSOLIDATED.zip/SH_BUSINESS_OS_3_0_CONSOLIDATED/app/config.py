from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "SH BUSINESS OS"
    app_env: str = "development"
    database_url: str
    jwt_secret: str
    jwt_expire_minutes: int = 30
    owner_email: str
    owner_password: str
    cors_origins: str = "http://localhost:3000"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
