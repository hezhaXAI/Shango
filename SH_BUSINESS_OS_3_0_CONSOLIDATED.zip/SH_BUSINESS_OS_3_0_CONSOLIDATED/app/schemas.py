from datetime import date
from decimal import Decimal
from pydantic import BaseModel, EmailStr, Field, ConfigDict

class LoginIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=256)

class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int

class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    email: EmailStr
    role: str

class AccountIn(BaseModel):
    code: str = Field(min_length=2, max_length=30)
    name_ku: str = Field(min_length=1, max_length=160)
    account_type: str = Field(pattern="^(asset|liability|equity|revenue|expense)$")
    currency: str | None = Field(default=None, pattern="^(USD|IQD)$")
    parent_id: int | None = None
    normal_balance: str = Field(default="debit", pattern="^(debit|credit)$")
    is_group: bool = False

class AccountOut(AccountIn):
    model_config = ConfigDict(from_attributes=True)
    id: int
    is_active: bool

class OpeningBalanceIn(BaseModel):
    effective_date: date
    description_ku: str = Field(default="باڵانسی دەستپێک", max_length=500)
    lines: list["JournalLineIn"] = Field(min_length=2)

class JournalLineIn(BaseModel):
    account_id: int
    side: str = Field(pattern="^(debit|credit)$")
    currency: str = Field(pattern="^(USD|IQD)$")
    amount: Decimal = Field(gt=0, max_digits=20, decimal_places=4)
    memo_ku: str | None = None

class JournalIn(BaseModel):
    entry_date: date
    description_ku: str = Field(min_length=2, max_length=500)
    source_module: str = Field(default="manual", max_length=40)
    lines: list[JournalLineIn] = Field(min_length=2)

class JournalOut(BaseModel):
    id: int
    entry_no: str
    status: str
    description_ku: str
    entry_date: date

class PeriodIn(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    starts_on: date
    ends_on: date

class PeriodOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    starts_on: date
    ends_on: date
    status: str

OpeningBalanceIn.model_rebuild()


class PartnerIn(BaseModel):
    partner_code: str = Field(min_length=2, max_length=30)
    name: str = Field(min_length=1, max_length=180)
    phone: str | None = Field(default=None, max_length=40)
    notes: str | None = Field(default=None, max_length=2000)

class PartnerOut(BaseModel):
    id: int
    partner_code: str
    name: str
    phone: str | None
    notes: str | None
    is_active: bool

class CapitalTransactionIn(BaseModel):
    partner_id: int
    transaction_date: date
    transaction_type: str = Field(pattern="^(contribution|withdrawal)$")
    currency: str = Field(pattern="^(USD|IQD)$")
    amount: Decimal = Field(gt=0, max_digits=20, decimal_places=4)
    reference: str | None = Field(default=None, max_length=100)
    notes: str | None = Field(default=None, max_length=500)

class CapitalTransactionOut(BaseModel):
    id: int
    partner_id: int
    transaction_date: date
    transaction_type: str
    currency: str
    amount: Decimal
    reference: str | None
    notes: str | None

class PartnerLoanIn(BaseModel):
    partner_id: int
    loan_date: date
    currency: str = Field(pattern="^(USD|IQD)$")
    principal_amount: Decimal = Field(gt=0, max_digits=20, decimal_places=4)
    due_date: date | None = None
    interest_rate: Decimal = Field(default=Decimal("0"), ge=0, max_digits=9, decimal_places=6)
    reference: str | None = Field(default=None, max_length=100)
    notes: str | None = Field(default=None, max_length=500)

class PartnerLoanOut(BaseModel):
    id: int
    loan_no: str
    partner_id: int
    loan_date: date
    currency: str
    principal_amount: Decimal
    due_date: date | None
    interest_rate: Decimal
    status: str
    outstanding_amount: Decimal

class PartnerLoanPaymentIn(BaseModel):
    payment_date: date
    amount: Decimal = Field(gt=0, max_digits=20, decimal_places=4)
    reference: str | None = Field(default=None, max_length=100)
    notes: str | None = Field(default=None, max_length=500)


class SourceJournalDraftIn(BaseModel):
    cash_account_id: int
    offset_account_id: int



class PropertyDealIn(BaseModel):
    deal_code: str = Field(min_length=2, max_length=40)
    title: str = Field(min_length=2, max_length=180)
    location: str = Field(min_length=2, max_length=240)
    area_sqm: Decimal | None = Field(default=None, gt=0, max_digits=18, decimal_places=4)
    currency: str = Field(pattern="^(USD|IQD)$")
    purchase_price: Decimal = Field(gt=0, max_digits=20, decimal_places=4)
    purchase_date: date
    title_document_ref: str | None = Field(default=None, max_length=300)
    notes: str | None = None

class PropertyDealOut(BaseModel):
    id: int
    deal_code: str
    title: str
    location: str
    area_sqm: Decimal | None
    currency: str
    purchase_price: Decimal
    purchase_date: date
    status: str
    title_document_ref: str | None
    notes: str | None

class PropertyParticipantIn(BaseModel):
    participant_name: str = Field(min_length=1, max_length=180)
    participant_type: str = Field(pattern="^(owner|outside_investor)$")
    partner_id: int | None = None
    contribution_amount: Decimal = Field(default=Decimal("0"), ge=0, max_digits=20, decimal_places=4)
    currency: str = Field(pattern="^(USD|IQD)$")
    legal_ownership_percent: Decimal | None = Field(default=None, ge=0, le=100, max_digits=7, decimal_places=4)
    profit_share_percent: Decimal | None = Field(default=None, ge=0, le=100, max_digits=7, decimal_places=4)
    agreement_ref: str | None = Field(default=None, max_length=300)
    notes: str | None = Field(default=None, max_length=500)

class PropertyExpenseIn(BaseModel):
    expense_date: date
    category: str = Field(min_length=2, max_length=80)
    amount: Decimal = Field(gt=0, max_digits=20, decimal_places=4)
    currency: str = Field(pattern="^(USD|IQD)$")
    notes: str | None = Field(default=None, max_length=500)

class PropertySaleIn(BaseModel):
    sale_date: date
    sale_amount: Decimal = Field(gt=0, max_digits=20, decimal_places=4)
    currency: str = Field(pattern="^(USD|IQD)$")
    received_amount: Decimal = Field(default=Decimal("0"), ge=0, max_digits=20, decimal_places=4)
    notes: str | None = Field(default=None, max_length=500)


class PropertyPaymentIn(BaseModel):
    payment_type: str = Field(pattern="^(participant_contribution|purchase_payment|sale_receipt)$")
    participant_id: int | None = None
    payment_date: date
    amount: Decimal = Field(gt=0, max_digits=20, decimal_places=4)
    currency: str = Field(pattern="^(USD|IQD)$")
    reference: str | None = Field(default=None, max_length=120)
    notes: str | None = Field(default=None, max_length=500)


class CommodityTradeIn(BaseModel):
    trade_no: str = Field(min_length=2, max_length=40)
    commodity_type: str = Field(pattern="^(fuel|gold|silver)$")
    direction: str = Field(pattern="^(purchase|sale)$")
    trade_date: date
    counterparty: str = Field(min_length=1, max_length=180)
    quantity: Decimal = Field(gt=0, max_digits=20, decimal_places=6)
    unit: str = Field(min_length=1, max_length=24)
    unit_price: Decimal = Field(gt=0, max_digits=20, decimal_places=6)
    currency: str = Field(pattern="^(USD|IQD)$")
    extra_cost: Decimal = Field(default=Decimal("0"), ge=0, max_digits=20, decimal_places=4)
    reference: str | None = Field(default=None, max_length=120)
    notes: str | None = Field(default=None, max_length=2000)

class ExternalInvestmentIn(BaseModel):
    investment_code: str = Field(min_length=2, max_length=40)
    company_name: str = Field(min_length=2, max_length=180)
    investment_date: date
    invested_amount: Decimal = Field(gt=0, max_digits=20, decimal_places=4)
    currency: str = Field(pattern="^(USD|IQD)$")
    ownership_percent: Decimal | None = Field(default=None, ge=0, le=100, max_digits=7, decimal_places=4)
    notes: str | None = None

class ExternalIncomeIn(BaseModel):
    income_date: date
    amount: Decimal = Field(gt=0, max_digits=20, decimal_places=4)
    currency: str = Field(pattern="^(USD|IQD)$")
    period_label: str | None = Field(default=None, max_length=40)
    notes: str | None = Field(default=None, max_length=500)

class InventoryItemIn(BaseModel):
    sku: str = Field(min_length=1, max_length=50)
    name: str = Field(min_length=1, max_length=180)
    category: str = Field(min_length=1, max_length=60)
    unit: str = Field(min_length=1, max_length=24)
    reorder_level: Decimal = Field(default=Decimal("0"), ge=0, max_digits=20, decimal_places=6)

class InventoryMovementIn(BaseModel):
    item_id: int
    movement_date: date
    movement_type: str = Field(pattern="^(in|out|adjustment)$")
    quantity: Decimal = Field(gt=0, max_digits=20, decimal_places=6)
    unit_cost: Decimal | None = Field(default=None, ge=0, max_digits=20, decimal_places=6)
    currency: str | None = Field(default=None, pattern="^(USD|IQD)$")
    reference: str | None = Field(default=None, max_length=120)
    notes: str | None = Field(default=None, max_length=500)

class CashBankMovementIn(BaseModel):
    movement_date: date
    account_id: int
    direction: str = Field(pattern="^(in|out)$")
    amount: Decimal = Field(gt=0, max_digits=20, decimal_places=4)
    currency: str = Field(pattern="^(USD|IQD)$")
    category: str = Field(min_length=1, max_length=80)
    reference: str | None = Field(default=None, max_length=120)
    notes: str | None = Field(default=None, max_length=500)
